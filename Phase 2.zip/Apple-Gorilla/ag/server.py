"""A tiny built-in web app for AG (stdlib only).

`python -m ag serve` starts a local server with a browser UI. Open it on this
machine, or from your phone/another device on the same network (bind --host
0.0.0.0). Cross-platform by virtue of being a web page — any OS with a browser.

The UI drives the same pipeline (execute with context, tools, and memory) and
streams a **realtime log** of AG's thought process, tool/app calls, internet usage,
errors, and the measured speed score as they happen (newline-delimited
JSON over a single streamed response). This IS an inbound server (for YOUR use); it
is not a data-farming endpoint — bind to localhost unless you deliberately want
LAN/phone access.
"""
from __future__ import annotations

import json
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .config import Config
from .model import make_client, Canceller, Cancelled
from .pipeline import run as run_pipeline


class _Interrupted(Exception):
    """Raised inside a run's on_delta when the viewer disconnects (Stop / closed tab),
    so generation is halted upstream instead of running to completion unseen."""

_PAGE_TEMPLATE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Apple-Gorilla</title>
__FONTS__
<style>__THEME__</style>
<style>
#improveout{margin-top:12px}
.result{padding:12px;border-radius:8px;background:rgba(127,127,127,.08);
  line-height:1.55;font-size:14px}
.result.ok{border-left:3px solid #3fb950}
.result.bad{border-left:3px solid #f85149}
table.hist{width:100%;border-collapse:collapse;margin-top:6px;font-size:13px}
table.hist td{padding:3px 6px;border-bottom:1px solid rgba(127,127,127,.15);
  vertical-align:top}
table.hist td.rat{color:#8b949e;font-style:italic}
#improve label.toggle{font-size:13px;opacity:.85;margin-left:auto}
#improve select{margin-left:6px}
/* live activity indicator on the pending reply bubble */
.body.pending{opacity:.85;font-style:italic}
.act-timer{opacity:.6;font-variant-numeric:tabular-nums;font-style:normal}
/* verbose live output (reasoning + streamed tokens) */
.verbose{margin-top:8px;font-size:12px}
.verbose summary{cursor:pointer;color:#8b949e}
.vbody{white-space:pre-wrap;max-height:260px;overflow:auto;margin-top:6px;padding:8px;
  border-radius:8px;background:rgba(127,127,127,.08);font-family:var(--mono),monospace;
  font-size:11px;line-height:1.45}
#stopbtn{background:#b91c1c;color:#fff}
</style></head><body>
<div class="wrap">
<header>
  <div class="logo">AG</div>
  <div class="brand"><h1>Apple-Gorilla<span class="ver" title="app version">v__VERSION__</span></h1>
    <div class="sub">self-improving prompt executor</div></div>
  <div id="status">ready</div>
</header>

<div id="update">
  <span class="g" id="updmsg"></span>
  <button class="yes" onclick="applyUpdate()">Yes, update</button>
  <button onclick="document.getElementById('update').style.display='none'">Dismiss</button>
</div>

<!-- where & how AG is running right now (populated from /whereami) -->
<div id="whereami" class="whereami" title="Where and how AG is running right now"></div>

<!-- when & how self-evolution is happening (populated from /doctor + /evolve/history) -->
<div id="evostatus" class="evostatus" title="When and how AG evolves itself">
  <span class="dot"></span><b>Evolve</b> loading status…
</div>

<!-- Claude sign-in (populated from /auth); lets `auto` use Claude instead of local -->
<div id="signin" class="whereami" title="Sign in so AG's auto backend uses Claude" hidden></div>

<!-- ================= tab command bar ================= -->
<nav class="tabs" id="tabs">
  <button class="tab active" data-pane="chat" onclick="switchTab('chat')">&#9656; Chat</button>
  <button class="tab" data-pane="fleet" onclick="switchTab('fleet')">&#9670; Fleet <span class="tct" id="tc-fleet"></span></button>
  <button class="tab" data-pane="skills" onclick="switchTab('skills')">&#10022; Skills <span class="tct" id="tc-skills"></span></button>
  <button class="tab" data-pane="evolve" onclick="switchTab('evolve')">&#8635; Evolve</button>
  <button class="tab" data-pane="lora" onclick="switchTab('lora')">&#9881; LoRA</button>
  <button class="tab" data-pane="bundle" onclick="switchTab('bundle')">&#10697; Bundle</button>
  <button class="tab" data-pane="images" onclick="switchTab('images')">&#9638; Media</button>
</nav>

<!-- ================= CHAT ================= -->
<div class="tabpane active" id="pane-chat">

<!-- Row: the message column scrolls independently, the reasoning sidebar streams the
     model's thoughts and tool/trace in parallel, and the input below stays pinned. -->
<div id="chatmain">
<div id="chatscroll">
<!-- context bar: lights up to show which sources feed the CURRENT answer -->
<div id="ctxbar" title="What AG is drawing on for the current answer — each lights up as it is used">
  <span class="ctxlbl">context in use:</span>
  <span class="chip" id="chip-history">Conversation <b class="cc" id="cc-history"></b></span>
  <span class="chip" id="chip-profile">Profile</span>
  <span class="chip" id="chip-memory">Memory <b class="cc" id="cc-memory"></b></span>
  <span class="chip" id="chip-web">Web <b class="cc" id="cc-web"></b></span>
  <span class="chip" id="chip-skills" title="Lights up when AG uses tools or acquires a new skill this run">Skills <b class="cc" id="cc-skills"></b></span>
</div>
<div class="panel chatwrap">
  <div class="chat-toolbar">
    <span class="ct-hint">earlier exchanges are kept here — scroll to revisit</span>
    <button class="linkbtn spacer" onclick="clearChat()">Clear conversation</button>
  </div>
  <div id="chat"></div>
</div>

<div id="cards">
  <div class="card"><div class="n" id="spd">–</div><div class="l">speed (measured)</div>
    <div class="bar"><i id="spdb"></i></div></div>
</div>
</div><!-- /chatscroll -->

<aside id="reasonbar">
  <div class="rb-head">Reasoning &amp; trace</div>
  <pre id="reasonstream" title="the model's live reasoning (enable 'show reasoning')"></pre>
  <div id="log"></div>
</aside>
</div><!-- /chatmain -->

<div class="panel" id="inputpanel">
  <textarea id="p" placeholder="Ask Apple-Gorilla anything…  (Ctrl+Enter to send)"></textarea>
  <div class="controls">
    <button class="cmd primary" id="runbtn" onclick="go()">Run</button>
    <button class="cmd" id="stopbtn" onclick="stopRun()" hidden>Stop</button>
    <span class="cmd-note">Ctrl+Enter to send</span>
    <!-- Generated from ag/controls.py — one declaration drives the markup, the
         browser's save/restore/collect, and the server's config overrides. Add a
         capability there, not here. -->
    <span class="ctl-right">
__CONTROLS__
    </span>
    <!-- Extended controls, tucked to the side. Specific model selection here OVERRIDES
         the automatic primary/specialist routing for a run. -->
    <details class="advanced">
      <summary title="model override and other advanced controls">Advanced</summary>
      <div class="adv-body">
__MODEL_PICKER__
        <span class="adv-note">picking a model overrides automatic routing for this run</span>
      </div>
    </details>
  </div>
</div>
</div><!-- /pane-chat -->

<!-- ================= FLEET ================= -->
<div class="tabpane" id="pane-fleet">
  <div class="panel">
    <p class="lede"><b>Agent swarm.</b> Every sub-agent AG spawns is registered here —
      named for the role it spawned as, with its parent, depth and how many skills it
      acquired. The <b>kill switch</b> halts all spawning and stops running loops.</p>
    <div class="fleet-bar">
      <button class="view" onclick="loadFleet()">Refresh</button>
      <button class="danger" onclick="fleetKill()">Engage kill switch</button>
      <button class="view" onclick="fleetRevive()">Clear kill switch</button>
      <span class="killbadge spacer" id="killbadge">kill: —</span>
    </div>
    <table class="dtable" id="fleettbl" style="display:none">
      <thead><tr><th>agent</th><th>role</th><th>parent</th><th>depth</th>
        <th>status</th><th class="n">skills</th><th></th></tr></thead>
      <tbody id="fleetbody"></tbody>
    </table>
    <div id="fleetempty" class="emptyrow">No sub-agents spawned yet. Delegation happens
      inside a run (the <code>delegate</code> tool) when tools are enabled.</div>
  </div>
</div>

<!-- ================= SKILLS ================= -->
<div class="tabpane" id="pane-skills">
  <div class="panel">
    <p class="lede"><b>Acquired skills.</b> Capabilities AG authored, tested, and
      registered — reused and inherited by sub-agents. Author one directly here, or turn
      on <b>self-extend</b> in Chat and just ask.</p>
    <textarea id="skspec" class="directive" rows="2"
      placeholder="Describe a capability to acquire, e.g. &quot;convert a CSV file to JSON&quot;. AG will author it, test it in isolation, and register it if the test passes."></textarea>
    <div class="controls" style="margin-top:0">
      <button class="cmd" id="skbtn" onclick="acquireSkill()">Acquire skill</button>
      <button class="view spacer" onclick="loadSkills()">Refresh list</button>
    </div>
    <div id="skacqout"></div>
    <div id="skillsout"></div>
  </div>
</div>

<!-- ================= EVOLVE ================= -->
<div class="tabpane" id="pane-evolve">
  <div class="panel" id="improve">
    <div class="btngroup cmd-group">
      <span class="grouplabel">Commands — run &amp; modify AG</span>
      <textarea id="directive" class="directive" rows="2"
        placeholder="Optional — tell Evolve what to improve in plain text (e.g. "make answers more concise", "sharpen the web-search prompt"). This steers the next Evolve; safety &amp; fitness gates still apply."></textarea>
      <div class="controls">
        <button class="cmd" onclick="doBench()">Benchmark</button>
        <button class="cmd evolve" onclick="doEvolve()">Evolve</button>
        <label class="toggle">proposer
          <select id="proposer">
            <option value="">deploy backend</option>
            <option value="anthropic">Claude (anthropic)</option>
            <option value="ollama">Ollama (local)</option>
          </select>
        </label>
      </div>
      <label class="ctl" style="margin-top:10px" title="Inject vetted reference code from your github_allowlist (config.evolve_github_refs) into the proposer's briefing so a self-edit can adapt proven implementations. Reference data only — evolve still edits only evolvable files and passes both gates."><input type="checkbox" id="evogithub"> use vetted GitHub references</label>
    </div>
    <div class="btngroup view-group">
      <span class="grouplabel">Views — read-only, change nothing</span>
      <div class="controls">
        <button class="view" onclick="loadTools()">Tools &amp; friction</button>
        <button class="view" onclick="loadHistory()">History</button>
        <button class="view" onclick="loadDoctor()">Status</button>
      </div>
    </div>
    <table id="tools" class="panel"></table>
    <div id="improveout"></div>
  </div>
</div>

<!-- ================= LORA ================= -->
<div class="tabpane" id="pane-lora">
  <div class="panel">
    <p class="lede"><b>LoRA fine-tuning.</b> Weight-level self-improvement of a
      <b>local</b> model (never Claude — no weight access): QLoRA a small base on a
      dataset distilled from AG's memory + a Claude teacher set. Needs an NVIDIA GPU and
      the training extras (<code>requirements-lora.txt</code>); heavy and explicit.</p>
    <div id="lorastatus" class="emptyrow">loading status…</div>
    <div class="controls" style="margin-top:6px">
      <label class="ctl">base model
        <select id="lorabase" class="ctl-select" onchange="loraSetBase()"><option>…</option></select>
      </label>
      <button class="help" data-help="The local model AG will fine-tune. Options are flagged for your GPU: 'fits' = comfortable, 'tight' = works with the memory-savers, 'won't fit' = inference-only. A LoRA adapter is bound to its base — it only works on this exact model.">?</button>
    </div>
    <div class="controls" style="margin-top:6px">
      <label class="ctl">epochs
        <input id="loraepochs" class="ctl-select" type="number" min="0.5" max="10" step="0.5"
               style="width:70px" onchange="loraSetOpts()">
      </label>
      <button class="help" data-help="How many passes over the dataset. More epochs learn the data harder (lower loss) but risk memorizing/overfitting on a small set. 1 is often too few; 3 is a solid default here.">?</button>
      <label class="toggle" style="margin-left:10px">
        <input type="checkbox" id="loraunsloth" onchange="loraSetOpts()"> use Unsloth
      </label>
      <button class="help" data-help="Unsloth trains ~2x faster in ~half the VRAM (needs a working C compiler). Off = the transformers+peft fallback, which is slower but needs no compiler. Turned off automatically if Unsloth isn't installed.">?</button>
    </div>
    <div class="controls" style="margin-top:6px">
      <button class="view" onclick="loadLora()">Refresh</button>
      <button class="cmd" onclick="loraBuild()">Build dataset</button>
      <button class="help" data-help="Assembles the training set from AG's own memory (high-scoring past runs + learned procedures) plus a Claude-generated teacher set. The teacher step calls the model, so it costs a few calls.">?</button>
      <button class="cmd" id="loratrain" onclick="loraTrain()">Train adapter</button>
      <button class="help" data-help="Runs one QLoRA fine-tune on the built dataset (needs a CUDA GPU + the training extras; uses Unsloth when installed). Heavy and long; runs in the background.">?</button>
    </div>
    <div id="loraout"></div>
  </div>
</div>

<!-- ================= BUNDLE ================= -->
<div class="tabpane" id="pane-bundle">
  <div class="panel">
    <p class="lede"><b>Portable bundle.</b> Pack AG and its learned state (profile,
      memory, skills, archive, config) into one archive for any Python 3.10+ host — the
      memory and skills travel with it. The check audits the portability constraints.</p>
    <div class="controls" style="margin-top:0">
      <button class="view" onclick="bundleCheck()">Check portability</button>
      <button class="cmd" onclick="bundleExport()">Export bundle</button>
    </div>
    <div id="bundleout"></div>
  </div>
</div>

<!-- ================= IMAGES ================= -->
<div class="tabpane" id="pane-images">
  <div class="panel" id="imagepanel">
    <span class="grouplabel">Media generation — on this machine's GPU <span class="cmd-note" id="imgnote"></span></span>
    <textarea id="imgprompt" class="directive" rows="2"
      placeholder="Describe an image or a clip to generate. Runs on your own GPU (ComfyUI, or an Automatic1111 server for images); the prompt never leaves your machine."></textarea>
    <div class="controls">
      <label class="ctl">make <select id="imgkind" class="ctl-select" onchange="syncMediaKind()">
        <option value="image">an image</option><option value="video">a video clip</option>
      </select></label>
      <label class="ctl" id="imgsecs-wrap" hidden>seconds <select id="imgsecs" class="ctl-select">
        <option value="2">2</option><option value="3" selected>3</option>
        <option value="5">5</option></select></label>
      <button class="cmd" id="imgbtn" onclick="genMedia()">Generate</button>
      <button class="cmd" id="imgstartbtn" onclick="startImageServer()" hidden>Start server</button>
    </div>
    <div id="imgout"></div>
  </div>
</div>

</div>
</div>

<script>
const $=id=>document.getElementById(id);
function escapeHtml(s){return (s||'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));}
function addEv(ev){
  const d=document.createElement('div');
  d.className='ev '+(ev.level||'info');
  d.innerHTML='<span class="tag">'+ev.stage+'</span>'+escapeHtml(ev.msg);
  $('log').appendChild(d); $('log').scrollTop=$('log').scrollHeight;
}
function setCard(id,v){ $(id).textContent=(v==null?'–':v);
  $(id+'b').style.width=((Number(v)||0)*10)+'%'; }

/* ---- conversation transcript (persisted locally) ---------------------- */
let CHAT=[];
function loadChat(){
  try{ CHAT=JSON.parse(localStorage.getItem('ag_chat')||'[]'); }catch(e){ CHAT=[]; }
  renderChat();
}
function saveChat(){
  try{ localStorage.setItem('ag_chat',JSON.stringify(CHAT.slice(-100))); }catch(e){}
}
function clearChat(){
  if(!CHAT.length||confirm('Clear the whole conversation?')){ CHAT=[]; saveChat(); renderChat(); }
}
// Scroll the message region to the newest content. Only auto-follows when the reader
// is already near the bottom (or force=true, e.g. right after they send), so scrolling
// up to re-read an earlier turn is never yanked back down mid-stream.
function scrollChat(force){
  const s=$('chatscroll'); if(!s) return;
  const nearBottom = s.scrollHeight - s.scrollTop - s.clientHeight < 120;
  if(force||nearBottom) s.scrollTop=s.scrollHeight;
}
function ctxFooter(c){
  if(!c) return '';
  const bits=[];
  if(c.model) bits.push(escapeHtml(c.model));
  if(c.history) bits.push(''+c.history+' prior turn'+(c.history>1?'s':''));
  if(c.profile) bits.push('profile');
  if(c.memory&&c.memory.length) bits.push(''+c.memory.length+' memory fact'+(c.memory.length>1?'s':''));
  if(c.web) bits.push(''+c.web+' web source'+(c.web>1?'s':''));
  if(c.saved&&c.saved.length) bits.push('remembered '+c.saved.length+' new fact'+(c.saved.length>1?'s':''));
  if(c.overall!=null) bits.push(''+c.overall+' overall');
  let h=bits.length? '<div class="ctx">'+bits.map(b=>'<span>'+escapeHtml(b)+'</span>').join('')+'</div>':'';
  if(c.memory&&c.memory.length){
    h+='<details class="memfacts"><summary>memory facts used</summary><ul>'
      +c.memory.map(f=>'<li>'+escapeHtml(f)+'</li>').join('')+'</ul></details>';
  }
  if(c.saved&&c.saved.length){
    h+='<details class="memfacts"><summary>saved to long-term memory</summary><ul>'
      +c.saved.map(f=>'<li>'+escapeHtml(f)+'</li>').join('')+'</ul></details>';
  }
  return h;
}
// Per-answer actions: rate (teaches the routing doc), regenerate, and copy a distilled
// prompt for Claude. prompt+model travel on the row so the handlers can attribute.
function aiActions(prompt,model){
  const dp=escapeHtml(prompt||''), dm=escapeHtml(model||'');
  return '<div class="airow" data-prompt="'+dp+'" data-model="'+dm+'">'
    +'<button class="ico" title="good answer" onclick="rate(this,&#39;rating_up&#39;)">&#128077;</button>'
    +'<button class="ico" title="poor answer" onclick="rate(this,&#39;rating_down&#39;)">&#128078;</button>'
    +'<button class="ico" title="regenerate this answer" onclick="regen(this)">&#8635;</button>'
    +'<button class="ico wide" title="copy a distilled prompt to paste into Claude" onclick="toClaude(this)">Claude &#10697;</button>'
    +'</div>';
}
function bubble(m,prev){
  const who=m.role==='user'?'you':'apple-gorilla';
  const t=m.ts?'<span class="ts">'+escapeHtml(m.ts)+'</span>':'';
  return '<div class="msg '+m.role+'"><div class="who">'+who+t+'</div>'
    +'<div class="body">'+escapeHtml(m.text)+'</div>'
    +(m.role==='ai'?ctxFooter(m.ctx)+aiActions(prev,(m.ctx&&m.ctx.model)||''):'')+'</div>';
}
function renderChat(){
  $('chat').innerHTML=CHAT.map((m,i)=>bubble(m, i>0?CHAT[i-1].text:'')).join('');
  scrollChat(true);
}
function appendUser(text){
  CHAT.push({role:'user',text:text,ts:nowStr()}); renderChat(); saveChat();
}
function nowStr(){ const d=new Date();
  return d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}); }
// live pending assistant bubble; returns the DOM node so we can fill it as we stream
function appendAssistant(){
  const el=document.createElement('div'); el.className='msg ai processing';
  el.innerHTML='<div class="who">apple-gorilla<span class="ts">'+nowStr()+'</span></div>'
    +'<div class="body pending"><span class="act-stage">…starting</span>'
    +'<span class="act-timer"></span></div>'
    +'<div class="live-ctx"></div>';
  $('chat').appendChild(el); scrollChat(true);
  return el;
}

/* ---- live activity indicator: what the model is doing + how long ------- */
/* Makes a snag visible: the stage label shows the current step and the timer
   keeps ticking, so a stall (timer climbing, stage unchanged) is obvious. */
const STAGE_LABELS={conversation:'reading the conversation',
  web:'searching the web',memory:'recalling memory',
  execute:'generating the answer',reason:'using tools',
  acquire:'acquiring a skill',score:'scoring speed'};
function fmtDur(ms){const s=Math.floor(ms/1000);
  return s>=60?(Math.floor(s/60)+':'+String(s%60).padStart(2,'0')):(s+'s');}
function startActivity(ai){
  ai._t0=Date.now();
  const tick=()=>{const el=ai.querySelector('.act-timer');
    if(el) el.textContent=' · '+fmtDur(Date.now()-ai._t0);};
  ai._timer=setInterval(tick,1000); tick();
}
function setStage(ai,ev){
  const lbl=STAGE_LABELS[ev.stage]; if(!lbl) return;
  const el=ai&&ai.querySelector('.act-stage');
  if(el){ el.textContent=lbl; ai._lastStage=Date.now(); }
}
function stopActivity(ai){ if(ai&&ai._timer){clearInterval(ai._timer); ai._timer=null;} }

/* ---- per-tab working-memory session id ------------------------------- */
const AG_SESSION=(function(){
  try{let s=sessionStorage.getItem('ag_session');
    if(!s){s='web-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
      sessionStorage.setItem('ag_session',s);}
    return s;
  }catch(e){return 'web-'+Date.now().toString(36);}
})();

/* ---- context-in-use indicator ---------------------------------------- */
let curCtx={history:0,profile:false,memory:[],saved:[],web:0,skills:0};
function resetContext(){
  curCtx={history:0,profile:false,memory:[],saved:[],web:0,skills:0};
  ['history','profile','memory','web','skills'].forEach(n=>$('chip-'+n).classList.remove('active'));
  $('cc-history').textContent=''; $('cc-memory').textContent=''; $('cc-web').textContent='';
  $('cc-skills').textContent='';
}
function applyContext(ev,ai){
  if(ev.stage==='conversation'){
    const m=/(\\d+)/.exec(ev.msg||''); const n=m?+m[1]:0;
    curCtx.history=n||curCtx.history; $('chip-history').classList.add('active');
    $('cc-history').textContent=(ev.data&&ev.data.turns)||n||'';
  }
  if(ev.stage==='optimize' && (/(profile)/i.test(ev.msg||'') || (ev.data&&ev.data.uses_profile))){
    curCtx.profile=true; $('chip-profile').classList.add('active');
  }
  if(ev.stage==='memory'){
    const f=(ev.data&&ev.data.facts)||[];
    const saved=(ev.data&&ev.data.saved)||[];
    $('chip-memory').classList.add('active');
    if(f.length){ curCtx.memory=f; $('cc-memory').textContent=f.length;
      if(ai){ const lc=ai.querySelector('.live-ctx');
        if(lc) lc.innerHTML='<div class="using">drawing on '+f.length
          +' remembered fact(s):</div><ul>'+f.map(x=>'<li>'+escapeHtml(x)+'</li>').join('')+'</ul>'; } }
    if(saved.length){ curCtx.saved=saved;
      // the save arrives AFTER the answer is committed — patch the finished bubble
      if(ai&&ai._committed&&ai._entry){
        ai._entry.ctx=ai._entry.ctx||{}; ai._entry.ctx.saved=saved; saveChat();
        ai.insertAdjacentHTML('beforeend',
          '<details class="memfacts" open><summary>saved '+saved.length
          +' fact(s) to long-term memory</summary><ul>'
          +saved.map(f=>'<li>'+escapeHtml(f)+'</li>').join('')+'</ul></details>');
      }
    }
  }
  if(ev.stage==='web'){
    let n=(ev.data&&ev.data.count); if(n==null){ const m=/(\\d+)\\s+result/.exec(ev.msg||''); n=m?+m[1]:null; }
    if(n!=null){ curCtx.web=n; $('chip-web').classList.add('active'); $('cc-web').textContent=n||''; }
  }
  // 'reason' = a tool was used; 'acquire' = a skill was authored/registered this run.
  if(ev.stage==='reason' || ev.stage==='acquire'){
    curCtx.skills++; $('chip-skills').classList.add('active');
    $('cc-skills').textContent=curCtx.skills;
  }
}

let CURRENT_ABORT=null, CURRENT_RUNID=null, RUN_STOPPED=false;
function setRunning(on){
  const rb=$('runbtn'), sb=$('stopbtn');
  if(rb){ rb.hidden=on; rb.disabled=on; }
  if(sb){ sb.hidden=!on; }
}
function stopRun(){
  $('status').textContent='stopping…'; RUN_STOPPED=true;
  // Signal the server to halt generation. We deliberately DON'T abort the fetch: we
  // keep reading so the server's stream loop reaches its cancel check and closes the
  // model connection from its own thread (a client abort can wedge the write on some
  // platforms). The server closes the stream right after it cancels.
  if(CURRENT_RUNID){ try{ fetch('/stop',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({run_id:CURRENT_RUNID})}); }catch(e){} }
}
async function go(){
  const p=$('p').value.trim(); if(!p)return;
  setRunning(true); $('status').textContent='running…';
  $('log').innerHTML=''; $('cards').style.display='none';
  if($('reasonstream')) $('reasonstream').textContent='';
  ['spd'].forEach(x=>setCard(x,null));
  // prior turns become AG's working memory (the current prompt is sent separately)
  const hist=CHAT.slice(-20).map(m=>({role:m.role,text:m.text}));
  resetContext(); appendUser(p); const ai=appendAssistant(); startActivity(ai); $('p').value='';
  const ctrl=new AbortController(); CURRENT_ABORT=ctrl; RUN_STOPPED=false;
  const runId=(self.crypto&&crypto.randomUUID)?crypto.randomUUID():String(Date.now())+Math.random();
  CURRENT_RUNID=runId;
  const verbose=$('verbose')?$('verbose').checked:false;
  try{
    // Every declared control goes along automatically — see AG_CONTROLS.
    const r=await fetch('/run',{method:'POST',headers:{'Content-Type':'application/json'},
      signal:ctrl.signal,
      body:JSON.stringify(Object.assign(ctlPayload(),
        {prompt:p,history:hist,model:($('model')?$('model').value:''),
         run_id:runId,session_id:AG_SESSION}))});
    const reader=r.body.getReader(), dec=new TextDecoder(); let buf='';
    while(true){
      const {value,done}=await reader.read(); if(done)break;
      buf+=dec.decode(value,{stream:true}); let nl;
      while((nl=buf.indexOf('\\n'))>=0){
        const line=buf.slice(0,nl).trim(); buf=buf.slice(nl+1);
        if(!line)continue; handle(JSON.parse(line),ai);
      }
    }
    // Stream ended without a final answer (e.g. dropped connection): say so plainly
    // rather than leaving the bubble stuck on the activity indicator forever.
    if(!ai._committed){ stopActivity(ai);
      const b=ai.querySelector('.body');
      if(b&&b.classList.contains('pending')){ b.className='body';
        b.textContent=RUN_STOPPED?'(stopped by you)'
          :'(the run ended without an answer — see the trace above)';
        ai.classList.remove('processing');
        $('status').textContent=RUN_STOPPED?'stopped':'ended'; } }
  }catch(e){
    stopActivity(ai);
    const b=ai.querySelector('.body'); b.className='body'; ai.classList.remove('processing');
    if(e&&e.name==='AbortError'){          // user hit Stop
      b.textContent='(stopped by you)'; $('status').textContent='stopped';
    } else {
      addEv({stage:'error',level:'error',msg:'request failed: '+e});
      $('status').textContent='error';
      b.textContent='(request failed: '+escapeHtml(''+e)+')';
    }
  }
  CURRENT_ABORT=null; CURRENT_RUNID=null; setRunning(false);
}
function handle(ev,ai){
  if(ev.stage==='delta'){   // live streamed model reasoning -> the sidebar, in parallel
    const rs=$('reasonstream');
    if(rs){ rs.textContent+=((ev.data&&ev.data.text)||''); rs.scrollTop=rs.scrollHeight; }
    return;
  }
  if(ev.stage==='progress'){ return; }   // heartbeat only (keeps Stop responsive)
  if(ev.stage==='error'){   // terminal pipeline error — make it visible, don't hang
    stopActivity(ai);
    const b=ai.querySelector('.body'); b.className='body';
    b.textContent=''+(ev.msg||'the run failed'); ai.classList.remove('processing');
    addEv(ev); $('status').textContent='error'; return;
  }
  if(ev.stage==='done'){
    stopActivity(ai);
    const d=ev.data||{};
    const b=ai.querySelector('.body'); b.className='body'; b.textContent=d.answer||'(no answer)';
    ai.classList.remove('processing');
    const lc=ai.querySelector('.live-ctx'); if(lc) lc.remove();
    const sc=d.scorecard||{};
    const ctx={history:curCtx.history,profile:curCtx.profile,memory:curCtx.memory,
               web:curCtx.web,saved:curCtx.saved,model:d.model_used||'',
               overall:(sc.overall!=null?sc.overall:null)};
    const prevPrompt=CHAT.length?CHAT[CHAT.length-1].text:'';
    ai.insertAdjacentHTML('beforeend',ctxFooter(ctx)+aiActions(prevPrompt,ctx.model));
    const entry={role:'ai',text:d.answer||'(no answer)',ctx:ctx,ts:nowStr()};
    CHAT.push(entry); ai._entry=entry; ai._committed=true; saveChat();
    scrollChat();
    $('status').textContent='done · '+(d.elapsed_s||0)+'s'+(d.dry_run?' · dry-run':'');
    checkUpdate();   // one on-demand check AFTER the run — never a background poll
    return;
  }
  setStage(ai,ev);
  applyContext(ev,ai);
  addEv(ev);
  const sc=(ev.data&&ev.data.scorecard);
  if(sc && sc.speed!=null){ $('cards').style.display='grid'; setCard('spd',sc.speed); }
}

/* ---- where & how AG is running right now ------------------------------ */
async function renderWhere(){
  try{
    const w=await fetch('/whereami').then(r=>r.json());
    let h='<span class="dot ok"></span>running at <b>'+escapeHtml(w.url)+'</b>';
    h+=w.local_only?' <span class="tagpill local">local-only</span>'
      :' <span class="tagpill lan">also on LAN: '+escapeHtml(w.lan_url||'')+'</span>';
    h+=' · brain <b>'+escapeHtml(w.brain)+'</b>';
    h+=w.evolving?' · <span class="tagpill evolving">evolving now — runs still work</span>'
      :' · <span class="tagpill idle">can evolve while running</span>';
    $('whereami').innerHTML=h;
    const eb=document.querySelector('button.cmd.evolve');
    if(eb) eb.disabled=!!w.evolving;
    return w;
  }catch(e){ $('whereami').innerHTML=''; return null; }
}

/* ---- evolve status: when & how self-improvement runs ------------------ */
async function renderEvoStatus(){
  const es=$('evostatus');
  try{
    const [doc,hist]=await Promise.all([
      fetch('/doctor').then(r=>r.json()),
      fetch('/evolve/history').then(r=>r.json())
    ]);
    const last=(hist.history||[])[0];
    const ready=(doc.evolve_gate||'').indexOf('ready')===0;
    let h='<span class="dot '+(ready?'ok':'off')+'"></span><b>Evolve</b> ';
    h+='gate '+(ready?'<span class="g-ok">ready</span>':'<span class="g-off">'+escapeHtml(doc.evolve_gate||'?')+'</span>');
    h+=' · proposer <b>'+escapeHtml(doc.evolver_backend||doc.effective_backend||doc.backend||'?')+'</b>';
    h+=' · verified by <b>'+(doc.fitness_gate?'benchmark + tests':'tests')+'</b>';
    h+=' · '+doc.snapshots+' snapshot(s)';
    if(last){
      const v=last.adopted?'OK adopted':escapeHtml(last.verdict||'no change');
      const dl=(last.delta!=null?' Δ'+last.delta:'');
      h+=' — last run <b>'+escapeHtml(last.ts||'')+'</b>: '+v+dl;
    }else{ h+=' — <i>no evolve runs yet</i>'; }
    es.classList.remove('busy'); es.innerHTML=h;
  }catch(e){ es.classList.remove('busy');
    es.innerHTML='<span class="dot off"></span><b>Evolve</b> status unavailable'; }
}
async function checkUpdate(){
  try{
    const s=await (await fetch('/update/check')).json();
    if(s.available){
      $('updmsg').textContent='A newer build of '+s.model+' is available. Update now?';
      $('update').style.display='flex';
    }
  }catch(e){ /* check is best-effort; stay silent on failure */ }
}
async function applyUpdate(){
  $('update').style.display='none';
  addEv({stage:'update',level:'tool',msg:'starting model update…'});
  try{
    const r=await fetch('/update/apply',{method:'POST'});
    const reader=r.body.getReader(), dec=new TextDecoder(); let buf='';
    while(true){
      const {value,done}=await reader.read(); if(done)break;
      buf+=dec.decode(value,{stream:true}); let nl;
      while((nl=buf.indexOf('\\n'))>=0){
        const line=buf.slice(0,nl).trim(); buf=buf.slice(nl+1);
        if(!line)continue; const ev=JSON.parse(line);
        addEv(ev.stage==='done'?{stage:'update',level:ev.level,msg:'update: '+ev.msg}:ev);
      }
    }
  }catch(e){ addEv({stage:'error',level:'error',msg:'update failed: '+e}); }
}
async function streamPost(url, body, onEvent){
  const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body||{})});
  const reader=r.body.getReader(), dec=new TextDecoder(); let buf='';
  while(true){ const {value,done}=await reader.read(); if(done)break;
    buf+=dec.decode(value,{stream:true}); let nl;
    while((nl=buf.indexOf('\\n'))>=0){ const line=buf.slice(0,nl).trim(); buf=buf.slice(nl+1);
      if(line) onEvent(JSON.parse(line)); } }
}
async function doBench(){
  $('log').innerHTML=''; $('improveout').innerHTML=''; $('status').textContent='benchmarking…';
  try{ await streamPost('/bench',{}, ev=>{
    if(ev.stage==='done'){ const d=ev.data||{};
      $('improveout').innerHTML='<div class="result"><b>Fitness '+d.fitness+'/10</b> · '
        +d.passed+'/'+d.n+' passed'
        +(d.failing&&d.failing.length?'<br>failing: '+escapeHtml(d.failing.join(', ')):'')+'</div>';
      $('status').textContent='bench: '+d.fitness+'/10'; return; }
    addEv(ev);
  }); }catch(e){ addEv({stage:'error',level:'error',msg:'bench failed: '+e});
    $('status').textContent='error'; }
}
// Step 1: ask AG to PROPOSE changes — nothing is applied. You then pick which to keep.
async function doEvolve(){
  $('log').innerHTML=''; $('improveout').innerHTML=''; $('status').textContent='proposing…';
  const directive=$('directive').value.trim();
  const es=$('evostatus'); es.classList.add('busy');
  es.innerHTML='<span class="dot spin"></span><b>Proposing changes…</b> '
    +(directive?'toward your request':'analysing AG');
  renderWhere();
  try{ await streamPost('/evolve/propose',{proposer:$('proposer').value,directive:directive,github:$('evogithub')?$('evogithub').checked:false}, ev=>{
    if(ev.stage==='done'){ renderProposal(ev.data||{});
      $('status').textContent='proposed'; renderEvoStatus(); renderWhere(); return; }
    if(ev.stage==='evolve'||ev.stage==='bench'){
      es.innerHTML='<span class="dot spin"></span><b>Proposing changes…</b> '+escapeHtml(ev.msg||''); }
    addEv(ev);
  }); }catch(e){ addEv({stage:'error',level:'error',msg:'propose failed: '+e});
    $('status').textContent='error'; renderEvoStatus(); renderWhere(); }
}
// Render the proposed changes as a checklist — YOU decide which to apply.
function renderProposal(d){
  const pts=d.patches||[];
  if(d.busy){ $('improveout').innerHTML='<div class="result">'+escapeHtml(d.reason||'evolve already running')+'</div>'; return; }
  if(!pts.length){ $('improveout').innerHTML='<div class="result">'+escapeHtml(d.reason||'no changes proposed')+'</div>'; return; }
  let h='<div class="proposal"><div class="phead"><b>Proposed changes — select the ones you want</b>'
    +'<span class="pnote">nothing is applied until you click Apply selected</span></div>';
  if(d.rationale) h+='<div class="prationale"><b>AG\\'s rationale:</b> '+escapeHtml(d.rationale)+'</div>';
  for(const p of pts){
    const dis=p.valid?'':'disabled';
    h+='<label class="pitem'+(p.valid?'':' invalid')+'">'
      +'<input type="checkbox" class="psel" value="'+escapeHtml(p.id)+'" '+(p.valid?'checked':'disabled')+'>'
      +'<span class="pmeta"><code>'+escapeHtml(p.path)+'</code> '
      +'<span class="pbytes">'+(p.bytes||0)+' B</span>'
      +(p.valid?'':'<span class="pbad">'+escapeHtml(p.error||'invalid')+'</span>')+'</span>';
    if(p.diff) h+='<details class="pdiff"><summary>view diff</summary><pre>'+escapeHtml(p.diff)+'</pre></details>';
    h+='</label>';
  }
  const anyValid=pts.some(p=>p.valid);
  h+='<div class="pactions">'
    +'<label class="toggle"><input type="checkbox" id="measurefit"> measure fitness impact (slow)</label>'
    +'<button class="cmd" onclick="applySelected()" '+(anyValid?'':'disabled')+'>OK Apply selected</button>'
    +'<button class="view" onclick="discardProposal()">Discard proposal</button>'
    +'<span class="pnote">safety tests still run on whatever you apply</span></div></div>';
  $('improveout').innerHTML=h;
}
function discardProposal(){ $('improveout').innerHTML=''; $('status').textContent='ready'; }
// Step 2: apply ONLY the changes you checked (safety tests still gate them).
async function applySelected(){
  const ids=[...document.querySelectorAll('.psel:checked')].map(c=>c.value);
  if(!ids.length){ $('status').textContent='select at least one change'; return; }
  const measure=!!($('measurefit')&&$('measurefit').checked);
  $('log').innerHTML=''; $('status').textContent='applying…';
  const es=$('evostatus'); es.classList.add('busy');
  es.innerHTML='<span class="dot spin"></span><b>Applying your selection…</b>';
  renderWhere();
  try{ await streamPost('/evolve/apply',{ids:ids,measure:measure}, ev=>{
    if(ev.stage==='done'){ const d=ev.data||{};
      if(d.busy){ $('improveout').innerHTML='<div class="result">'+escapeHtml(d.reason||'evolve already running')+'</div>';
        renderEvoStatus(); renderWhere(); return; }
      const cls=d.adopted?'ok':(d.rolled_back?'bad':'');
      let h='<div class="result '+cls+'"><b>'
        +(d.adopted?'OK Applied & kept':(d.rolled_back?'-> Reverted (safety)':'Not applied'))
        +'</b><br>'+escapeHtml(d.reason||'')+'<br>';
      if(d.delta!=null) h+='fitness '+d.incumbent+'→'+(d.candidate!=null?d.candidate:'?')
        +'/10 (Δ'+d.delta+', informational)<br>';
      if(d.changed&&d.changed.length) h+='files: '+escapeHtml(d.changed.join(', '))+'<br>';
      if(d.snapshot_id) h+='<span class="pnote">snapshot '+escapeHtml(d.snapshot_id)+' — revert with: ag rollback '+escapeHtml(d.snapshot_id)+'</span>';
      h+='</div>'; $('improveout').innerHTML=h;
      $('status').textContent='evolve: '+(d.adopted?'applied':(d.rolled_back?'reverted':'no change'));
      if(d.adopted) $('directive').value='';
      renderEvoStatus(); renderWhere();
      return; }
    if(ev.stage==='evolve'||ev.stage==='bench'){
      es.innerHTML='<span class="dot spin"></span><b>Applying your selection…</b> '+escapeHtml(ev.msg||''); }
    addEv(ev);
  }); }catch(e){ addEv({stage:'error',level:'error',msg:'apply failed: '+e});
    $('status').textContent='error'; renderEvoStatus(); renderWhere(); }
}
async function loadHistory(){
  const d=await (await fetch('/evolve/history')).json();
  if(!d.history||!d.history.length){
    $('improveout').innerHTML='<div class="result">No evolution history yet — click Evolve.</div>';
    return; }
  let h='<div class="result"><b>Fitness lineage</b> (newest first)<table class="hist">';
  for(const r of d.history){
    const mark=r.adopted?'OK adopted':'· '+(r.verdict||'n/a');
    let fit='';
    if(r.incumbent_fitness!=null&&r.candidate_fitness!=null)
      fit=r.incumbent_fitness+'→'+r.candidate_fitness+'/10 (Δ'+r.delta+')';
    h+='<tr><td>'+escapeHtml(r.ts||'')+'</td><td>'+mark+'</td><td>'+fit+'</td></tr>';
    if(r.rationale) h+='<tr><td colspan="3" class="rat">'+escapeHtml(r.rationale.slice(0,140))+'</td></tr>';
  }
  h+='</table></div>'; $('improveout').innerHTML=h;
}
async function loadDoctor(){
  const d=await (await fetch('/doctor')).json();
  let h='<div class="result"><b>Status</b><br>';
  h+='backend: '+d.backend+' → '+d.effective_backend+'<br>';
  h+='ollama: '+(d.ollama_reachable?('reachable — '+(d.ollama_models.join(', ')||'no models pulled'))
    :'not reachable')+'<br>';
  h+='fitness gate: '+(d.fitness_gate?'ON':'off')+' — '+d.bench_tasks+' tasks, '
    +d.bench_samples+' samples ('+d.bench_mode+')<br>';
  h+='evolve gate: '+d.evolve_gate+' · snapshots: '+d.snapshots+'<br>';
  if(d.evolver_backend) h+='proposer backend: '+d.evolver_backend+'<br>';
  if(d.last_improvement){ const l=d.last_improvement;
    h+='last improvement: Δ'+l.delta+' → '+l.candidate_fitness+'/10<br>'; }
  h+='</div>'; $('improveout').innerHTML=h;
}
async function loadTools(){
  const t=$('tools');
  if(t.style.display==='table'){ t.style.display='none'; return; }
  const d=await (await fetch('/tools')).json();
  let h='<tr><th>tool</th><th>category</th><th>status</th>'
    +'<th class="n">integ</th><th class="n">friction</th></tr>';
  for(const x of d.tools){ h+='<tr><td>'+escapeHtml(x.name)+'</td><td>'+x.category
    +'</td><td><span class="pill '+x.status+'">'+x.status+'</span></td>'
    +'<td class="n">'+x.integration+'</td><td class="n">'+x.friction+'</td></tr>'; }
  h+='<tr><td colspan="5">avg integration '+d.avg_integration
    +' · avg friction '+d.avg_friction+' · best evolve target: '
    +escapeHtml(d.highest_friction_wired||'–')+'</td></tr>';
  t.innerHTML=h; t.style.display='table';
}
/* ---- run controls ------------------------------------------------------
   Everything below is generic: it reads the declaration shipped from
   ag/controls.py, so a new control needs no JavaScript at all. */
const AG_CONTROLS=__CONTROLS_JSON__;
function ctlEl(c){ return $(c.id); }
function ctlGet(c){ const el=ctlEl(c); if(!el) return null;
  return c.kind==='toggle' ? el.checked : el.value; }
function ctlSet(c,v){ const el=ctlEl(c); if(!el) return;
  if(c.kind==='toggle') el.checked=!!v; else el.value=v; }
/* Live = this control can actually affect the run. A control whose prerequisite is
   off is disabled, cleared and dimmed, so the bar never offers a switch that does
   nothing. The server enforces the same rule; the page is not the authority. */
function ctlLive(c){
  if(!c.requires) return true;
  const dep=AG_CONTROLS.find(x=>x.id===c.requires); if(!dep) return true;
  const el=ctlEl(dep); if(!el) return true;
  return ctlLive(dep) && (dep.kind==='toggle' ? el.checked : !!el.value);
}
function syncCtls(){
  for(const c of AG_CONTROLS){
    const el=ctlEl(c); if(!el) continue;
    const live=ctlLive(c);
    el.disabled=!live;
    if(!live && c.kind==='toggle') el.checked=false;
    const wrap=$(c.id+'-wrap'); if(wrap) wrap.style.opacity=live?'1':'.45';
  }
  saveCtls();
}
function saveCtls(){ try{ for(const c of AG_CONTROLS){ const v=ctlGet(c);
  if(v===null) continue;
  localStorage.setItem('ag_ctl_'+c.id, c.kind==='toggle'?(v?'1':'0'):String(v));
}}catch(e){} }
function restoreCtls(){ try{ for(const c of AG_CONTROLS){
  if(!ctlEl(c)) continue;
  const raw=localStorage.getItem('ag_ctl_'+c.id);
  if(raw==null) ctlSet(c,c.default);
  else ctlSet(c, c.kind==='toggle' ? raw==='1' : raw);
}}catch(e){} syncCtls(); }
function ctlPayload(){ const out={};
  for(const c of AG_CONTROLS){ const v=ctlGet(c); if(v!==null) out[c.id]=v; }
  return out; }
function saveModel(){ try{ localStorage.setItem('ag_model',$('model').value); }catch(e){} }
async function loadModels(){
  const sel=$('model'); if(!sel) return;
  try{
    const d=await fetch('/models').then(r=>r.json());
    sel.innerHTML='';
    if(!d.options||!d.options.length){
      sel.innerHTML='<option value="">'+(d.ollama_reachable===false
        ?'(Ollama not reachable)':'(no models found)')+'</option>'; return; }
    for(const o of d.options){ const opt=document.createElement('option');
      opt.value=o.value; opt.textContent=o.label; sel.appendChild(opt); }
    let saved=null; try{ saved=localStorage.getItem('ag_model'); }catch(e){}
    const vals=d.options.map(o=>o.value);
    sel.value=(saved&&vals.includes(saved))?saved:(d.current||d.options[0].value);
  }catch(e){ sel.innerHTML='<option value="">(could not load models)</option>'; }
}
/* ---- Claude sign-in ---------------------------------------------------- */
async function loadAuth(){
  const el=$('signin'); if(!el) return;
  try{
    const a=await fetch('/auth').then(r=>r.json());
    el.hidden=false;
    if(a.signed_in){
      el.innerHTML='Signed in to Claude ('+escapeHtml(a.method)+') — available as <b>'
        +escapeHtml(a.model)+'</b>, used only when you pick it in the model menu (spends API tokens). '
        +'AG answers locally by default. <button class="linkbtn" onclick="logoutClaude()">sign out</button>';
    } else {
      el.innerHTML='Not signed in to Claude — running locally. '
        +'<a href="'+escapeHtml(a.console_url)+'" target="_blank" rel="noopener">Get an API key</a>, '
        +'paste it: <input id="apikey" type="password" placeholder="sk-ant-…" '
        +'style="width:210px;vertical-align:middle"> '
        +'<button class="cmd" onclick="saveKey()">Sign in</button>'
        +'<div class="ct-hint">On a Claude subscription? Install Claude Code and run its '
        +'login (or `ant auth login`) — AG reads that OAuth profile automatically.</div>';
    }
  }catch(e){}
}
async function saveKey(){
  const f=$('apikey'); const k=f?f.value.trim():''; if(!k) return;
  try{
    const r=await fetch('/login/key',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({key:k})}).then(r=>r.json());
    if(r.ok){ if(f) f.value=''; loadAuth(); loadModels(); renderWhere();
      $('status').textContent='signed in to Claude'; }
    else { alert('Sign in failed: '+(r.error||'unknown')); }
  }catch(e){ alert('Sign in failed: '+e); }
}
async function logoutClaude(){
  try{ await fetch('/logout',{method:'POST'}); }catch(e){}
  loadAuth(); loadModels(); renderWhere(); syncMediaKind();
}
/* ---- local image generation ------------------------------------------ */
async function loadImageStatus(){
  const n=$('imgnote'), sb=$('imgstartbtn'); if(!n) return;
  try{
    const s=await fetch('/image/status').then(r=>r.json());
    const k=$('imgkind'); if(k && !s.video){ k.value='image'; k.disabled=true; syncMediaKind(); }
    if(!s.enabled){ n.textContent='· disabled in config'; if(sb) sb.hidden=true; }
    else if(s.reachable){ n.textContent='· ready · '+escapeHtml(s.backend)+' at '+escapeHtml(s.host); if(sb) sb.hidden=true; }
    else { n.textContent='· no '+escapeHtml(s.backend)+' server at '+escapeHtml(s.host)
        +' — click Start server'
        +(s.models&&s.models.length?' (needs: '+escapeHtml(s.models.join(', '))+')':'');
      if(sb) sb.hidden=false; }
  }catch(e){}
}
async function startImageServer(){
  const n=$('imgnote'), sb=$('imgstartbtn');
  if(sb) sb.disabled=true; if(n) n.textContent='· starting image server (first start loads a model — up to a few minutes)…';
  try{
    const r=await fetch('/image/start',{method:'POST'}).then(r=>r.json());
    if(!r.ok && n) n.textContent='· '+escapeHtml(r.error||'could not start the server');
  }catch(e){ if(n) n.textContent='· start failed: '+escapeHtml(''+e); }
  if(sb) sb.disabled=false;
  loadImageStatus();
}
function mediaKind(){ return $('imgkind') ? $('imgkind').value : 'image'; }
function syncMediaKind(){
  const w=$('imgsecs-wrap'); if(w) w.hidden = mediaKind()!=='video';
}
async function genMedia(){
  const p=$('imgprompt')?$('imgprompt').value.trim():''; if(!p) return;
  const kind=mediaKind(), btn=$('imgbtn'), out=$('imgout');
  if(btn) btn.disabled=true;
  if(out) out.innerHTML='<div class="ct-hint">generating'
    +(kind==='video'?' a clip — this takes minutes, not seconds':'')
    +'… (if the server is not running AG will start it first — the first run loads a multi-GB model)</div>';
  try{
    const body={prompt:p};
    if(kind==='video' && $('imgsecs')) body.seconds=parseFloat($('imgsecs').value);
    const r=await fetch(kind==='video'?'/video':'/image',
      {method:'POST',headers:{'Content-Type':'application/json'},
       body:JSON.stringify(body)}).then(r=>r.json());
    if(r.ok && kind==='video'){
      out.innerHTML='<video controls style="max-width:100%;border-radius:10px;margin-top:8px" '
        +'src="/media?path='+encodeURIComponent(r.path)+'"></video>'
        +'<div class="ct-hint">'+r.seconds+'s · saved to '+escapeHtml(r.path)+'</div>'; }
    else if(r.ok){ out.innerHTML='<img src="'+r.data_url+'" alt="'+escapeHtml(p)
      +'" style="max-width:100%;border-radius:10px;margin-top:8px">'
      +'<div class="ct-hint">saved to '+escapeHtml(r.path)+'</div>'; }
    else { out.innerHTML='<div class="result bad">'+escapeHtml(r.error||'failed')+'</div>'; }
  }catch(e){ out.innerHTML='<div class="result bad">request failed: '+escapeHtml(''+e)+'</div>'; }
  if(btn) btn.disabled=false;
}
// restore the transcript and status (where it runs + evolve) as soon as the page loads
/* ---- help popovers (click to open; works on touch) ------------------- */
let HELP_POP=null;
function closeHelp(){ if(HELP_POP){ HELP_POP.remove(); HELP_POP=null; } }
document.addEventListener('click', function(e){
  const btn=e.target.closest && e.target.closest('.help');
  if(btn){
    e.preventDefault(); e.stopPropagation();
    const txt=btn.getAttribute('data-help')||'';
    if(HELP_POP && HELP_POP._for===btn){ closeHelp(); return; }
    closeHelp();
    const p=document.createElement('div'); p.className='help-pop'; p._for=btn;
    p.innerHTML='<span class="hx" onclick="closeHelp()">\\u2715</span>'+escapeHtml(txt);
    document.body.appendChild(p);
    const r=btn.getBoundingClientRect();
    let left=Math.min(r.left, window.innerWidth-p.offsetWidth-12);
    let top=r.bottom+6;
    if(top+p.offsetHeight>window.innerHeight-8) top=Math.max(8,r.top-p.offsetHeight-6);
    p.style.left=Math.max(8,left)+'px'; p.style.top=top+'px';
    HELP_POP=p; return;
  }
  if(HELP_POP && !e.target.closest('.help-pop')) closeHelp();
});
window.addEventListener('resize', closeHelp);

/* ---- tabs ------------------------------------------------------------- */
function switchTab(name){
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.pane===name));
  document.querySelectorAll('.tabpane').forEach(p=>p.classList.toggle('active',p.id==='pane-'+name));
  try{ localStorage.setItem('ag_tab',name); }catch(e){}
  if(name==='fleet') loadFleet();
  if(name==='skills') loadSkills();
  if(name==='lora') loadLora();
}
/* ---- lora ------------------------------------------------------------- */
let LORA_POLL=null;
let LORA_MERGE_READY=false;
async function loadLora(){
  try{
    const d=await (await fetch('/lora/status')).json();
    const f=d.feasibility||{};
    const tr=d.training||{};
    LORA_MERGE_READY=!!d.merge_ready;
    // base selector, annotated with fit for this GPU
    const sel=$('lorabase');
    if(sel){ sel.innerHTML=(d.bases||[]).map(b=>'<option value="'+escapeHtml(b.id)+'"'
      +(b.id===d.base?' selected':'')+'>'+escapeHtml(b.id)+' · '+b.params_b+'B · '+b.fit
      +'</option>').join(''); }
    const ep=$('loraepochs'); if(ep && d.epochs!=null) ep.value=d.epochs;
    const us=$('loraunsloth');
    if(us){ us.checked=!!d.unsloth_pref; us.disabled=!(f.unsloth); }
    $('lorastatus').className='kv';
    $('lorastatus').innerHTML=
      'GPU <b>'+escapeHtml(f.gpu||'?')+'</b> · VRAM <b>'+(f.vram_gb==null?'?':f.vram_gb+' GB')
      +'</b> · CUDA <b>'+(f.cuda?'yes':'no')+'</b> · Unsloth <b>'+(f.unsloth?'yes':'no')
      +'</b><br>dataset <b>'+(d.dataset_size||0)+'</b> example(s) · adapters <b>'
      +(d.adapters||[]).length+'</b> · merge→Ollama <b>'+(d.merge_ready?'ready':'not set up')+'</b>'
      +'<br>trainable now: <b>'+(f.ok?'YES':'no')+'</b>'
      +(f.missing_deps&&f.missing_deps.length?' · missing: '+escapeHtml(f.missing_deps.join(', ')):'')
      +((f.notes||[]).map(n=>'<br>&nbsp;• '+escapeHtml(n)).join(''))
      +(tr.running?'<br><b>LoRA job in progress…</b>':(tr.last?'<br>last: '+escapeHtml(tr.last):''));
    $('loratrain').disabled=!!tr.running;
    const ad=(d.adapters||[]);
    $('loraout').innerHTML = ad.length
      ? ad.map(a=>'<div class="skitem"><span class="sknm">'+escapeHtml(a.id)+'</span>'
          +'<span class="skds">base '+escapeHtml(a.base||'?')+' · '+(a.examples||'?')+' examples'
          +(a.unsloth?' · unsloth':'')+'</span>'
          +(LORA_MERGE_READY?'<button class="linkbtn" onclick="loraMerge(\\''+escapeHtml(a.id)
             +'\\')">merge → Ollama</button>':'')+'</div>').join('')
      : '<div class="emptyrow">No adapters yet. Build a dataset, then train.</div>';
    if(tr.running && !LORA_POLL){ LORA_POLL=setInterval(loadLora,4000); }
    if(!tr.running && LORA_POLL){ clearInterval(LORA_POLL); LORA_POLL=null; }
  }catch(e){ $('lorastatus').textContent='could not load LoRA status: '+e; }
}
async function loraSetBase(){
  const base=$('lorabase').value;
  try{ await fetch('/lora/set-base',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({base:base})}); }catch(e){}
  loadLora();
}
async function loraSetOpts(){
  const epochs=parseFloat($('loraepochs').value);
  const unsloth=$('loraunsloth').checked;
  try{ await fetch('/lora/set-opts',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({epochs:epochs,unsloth:unsloth})}); }catch(e){}
  loadLora();
}
async function loraMerge(adapter){
  if(!confirm('Merge "'+adapter+'" into its base, convert to GGUF, and register it with Ollama? This is heavy and long.')) return;
  try{
    const d=await (await fetch('/lora/merge',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({adapter:adapter})})).json();
    if(!d.started){ $('loraout').innerHTML='<div class="result bad">'+escapeHtml(d.reason||'could not start')+'</div>'; }
    else{ $('loraout').innerHTML='<div class="result">merge started — runs in the background; status updates above.</div>'; }
    loadLora();
  }catch(e){ $('loraout').innerHTML='<div class="result bad">merge failed to start: '+escapeHtml(''+e)+'</div>'; }
}
async function loraBuild(){
  $('loraout').innerHTML='<div class="result">building dataset (memory + teacher — the teacher set calls the model)…</div>';
  try{
    const d=await (await fetch('/lora/build',{method:'POST'})).json();
    $('loraout').innerHTML='<div class="result ok">dataset: '+(d.total||0)+' example(s) ('
      +(d.from_memory||0)+' from memory, '+(d.from_teacher||0)+' from teacher)</div>';
    loadLora();
  }catch(e){ $('loraout').innerHTML='<div class="result bad">build failed: '+escapeHtml(''+e)+'</div>'; }
}
async function loraTrain(){
  if(!confirm('Start a QLoRA training run? This is heavy and can take a long time.')) return;
  try{
    const d=await (await fetch('/lora/train',{method:'POST'})).json();
    if(!d.started){ $('loraout').innerHTML='<div class="result bad">'+escapeHtml(d.reason||'could not start')+'</div>'; }
    else{ $('loraout').innerHTML='<div class="result">training started — this runs in the background; status updates above.</div>'; }
    loadLora();
  }catch(e){ $('loraout').innerHTML='<div class="result bad">train failed to start: '+escapeHtml(''+e)+'</div>'; }
}
function restoreTab(){ let t='chat'; try{ t=localStorage.getItem('ag_tab')||'chat'; }catch(e){}
  if(!document.getElementById('pane-'+t)) t='chat'; switchTab(t); }

/* ---- fleet ------------------------------------------------------------ */
async function loadFleet(){
  try{
    const d=await (await fetch('/fleet')).json();
    const kb=$('killbadge');
    kb.textContent='kill: '+(d.kill_active?'ENGAGED':'off');
    kb.classList.toggle('on',!!d.kill_active);
    const agents=d.agents||[];
    $('tc-fleet').textContent=agents.length?('['+agents.length+']'):'';
    const tbl=$('fleettbl'), body=$('fleetbody'), empty=$('fleetempty');
    if(!agents.length){ tbl.style.display='none'; empty.style.display='block'; return; }
    empty.style.display='none'; tbl.style.display='table';
    body.innerHTML=agents.map(a=>'<tr><td>'+escapeHtml(a.agent)+'</td><td>'+escapeHtml(a.role)
      +'</td><td>'+escapeHtml(a.parent)+'</td><td class="n">'+a.depth
      +'</td><td><span class="pill '+escapeHtml(a.status)+'">'+escapeHtml(a.status)+'</span></td>'
      +'<td class="n">'+a.skills_acquired+'</td><td>'
      +(a.status==='disabled'
        ?'<button class="linkbtn" onclick="fleetAct(\\''+escapeHtml(a.agent)+'\\',\\'enable\\')">enable</button>'
        :'<button class="linkbtn" onclick="fleetAct(\\''+escapeHtml(a.agent)+'\\',\\'disable\\')">disable</button>')
      +'</td></tr>').join('');
  }catch(e){ $('fleetempty').textContent='could not load fleet: '+e; }
}
async function fleetAct(agent,action){
  try{ await fetch('/fleet/act',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:action,agent:agent})}); }catch(e){}
  loadFleet();
}
async function fleetKill(){
  if(!confirm('Engage the kill switch? This halts ALL sub-agent spawning and stops running loops.')) return;
  try{ await fetch('/fleet/act',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'kill'})}); }catch(e){}
  loadFleet();
}
async function fleetRevive(){
  try{ await fetch('/fleet/act',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:'revive'})}); }catch(e){}
  loadFleet();
}

/* ---- skills ----------------------------------------------------------- */
async function loadSkills(){
  try{
    const d=await (await fetch('/skills')).json();
    const sk=d.skills||[];
    $('tc-skills').textContent=sk.length?('['+sk.length+']'):'';
    const out=$('skillsout');
    if(!sk.length){ out.innerHTML='<div class="emptyrow">No skills acquired yet. '
      +'Author one above, or enable self-extend in Chat and ask for a capability.</div>'; return; }
    out.innerHTML=sk.map(s=>'<div class="skitem"><span class="sknm">'+escapeHtml(s.name)+'</span>'
      +'<span class="skds">'+escapeHtml(s.description)
      +(s.capabilities&&s.capabilities.length?' <span class="skcap">['+escapeHtml(s.capabilities.join(', '))+']</span>':'')
      +'</span><span class="pill '+(s.enabled?'ok':'disabled')+'">'+(s.enabled?'enabled':'disabled')+'</span>'
      +'<button class="linkbtn" onclick="skillAct(\\''+escapeHtml(s.name)+'\\',\\''+(s.enabled?'disable':'enable')+'\\')">'
      +(s.enabled?'disable':'enable')+'</button>'
      +'<button class="linkbtn" onclick="skillAct(\\''+escapeHtml(s.name)+'\\',\\'remove\\')">remove</button></div>').join('');
  }catch(e){ $('skillsout').innerHTML='<div class="emptyrow">could not load skills: '+escapeHtml(''+e)+'</div>'; }
}
async function skillAct(name,action){
  if(action==='remove' && !confirm('Remove skill "'+name+'"? This deletes it from the registry.')) return;
  try{ await fetch('/skills/act',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({action:action,name:name})}); }catch(e){}
  loadSkills();
}
async function acquireSkill(){
  const spec=$('skspec').value.trim(); if(!spec) return;
  const btn=$('skbtn'); btn.disabled=true;
  $('skacqout').innerHTML='<div class="result">authoring &amp; testing a skill for: '
    +escapeHtml(spec)+' … (this calls the model and may take a moment)</div>';
  try{
    const d=await (await fetch('/skills/acquire',{method:'POST',
      headers:{'Content-Type':'application/json'},body:JSON.stringify({spec:spec})})).json();
    $('skacqout').innerHTML='<div class="result '+(d.acquired?'ok':'bad')+'">'
      +escapeHtml(d.reason||(d.acquired?'acquired':'not acquired'))+'</div>';
    if(d.acquired){ $('skspec').value=''; loadSkills(); }
  }catch(e){ $('skacqout').innerHTML='<div class="result bad">acquire failed: '+escapeHtml(''+e)+'</div>'; }
  btn.disabled=false;
}

/* ---- bundle ----------------------------------------------------------- */
async function bundleCheck(){
  $('bundleout').innerHTML='<div class="result">running portability audit…</div>';
  try{
    const d=await (await fetch('/bundle/check')).json();
    const rows=(d.checks||[]).map(c=>'<div class="bcheck '+(c.ok?'ok':'bad')+'"><span class="led"></span>'
      +'<div><div>'+escapeHtml(c.name)+'</div>'+(c.detail?'<div class="bd">'+escapeHtml(c.detail)+'</div>':'')+'</div></div>').join('');
    $('bundleout').innerHTML=rows+'<div class="result '+(d.portable?'ok':'bad')+'">'
      +(d.portable?'Portable — all constraints satisfied.':'NOT fully portable — see failures above.')+'</div>';
  }catch(e){ $('bundleout').innerHTML='<div class="result bad">check failed: '+escapeHtml(''+e)+'</div>'; }
}
async function bundleExport(){
  $('bundleout').innerHTML='<div class="result">packing bundle…</div>';
  try{
    const d=await (await fetch('/bundle/export',{method:'POST'})).json();
    $('bundleout').innerHTML='<div class="result ok">Bundle written on the AG host:<br><code>'
      +escapeHtml(d.path||'')+'</code>'+(d.bytes?(' &middot; '+Math.round(d.bytes/1024)+' KB'):'')+'</div>';
  }catch(e){ $('bundleout').innerHTML='<div class="result bad">export failed: '+escapeHtml(''+e)+'</div>'; }
}
function saveEvoGithub(){ try{ localStorage.setItem('ag_evogithub',$('evogithub').checked?'1':'0'); }catch(e){} }
function restoreEvoGithub(){ try{ const v=localStorage.getItem('ag_evogithub');
  if($('evogithub')) $('evogithub').checked=(v==='1'); }catch(e){}
  if($('evogithub')) $('evogithub').addEventListener('change',saveEvoGithub); }

// Per-answer actions. Rating and escalation feed AG's model-routing doc; regenerate
// re-asks. prompt+model ride on the .airow so each handler can attribute correctly.
function _rowData(btn){ const r=btn.closest('.airow');
  return r?{row:r,prompt:r.getAttribute('data-prompt')||'',model:r.getAttribute('data-model')||''}:null; }
function _sendRate(prompt,model,signal){
  fetch('/rate',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({prompt:prompt,model:model,signal:signal})}).catch(()=>{}); }
function rate(btn,signal){ const d=_rowData(btn); if(!d) return;
  _sendRate(d.prompt,d.model,signal);
  // 👍 and 👎 are the first two icons; make them mutually exclusive and mark the choice.
  const icos=d.row.querySelectorAll('.ico');
  if(icos[0]) icos[0].classList.remove('on');
  if(icos[1]) icos[1].classList.remove('on');
  btn.classList.add('on'); }
function regen(btn){ const d=_rowData(btn); if(!d||!d.prompt) return;
  _sendRate(d.prompt,d.model,'rating_down');   // a regenerate = this wasn't good enough
  $('p').value=d.prompt; go(); }
function toClaude(btn){ const d=_rowData(btn); if(!d) return;
  const msg=btn.closest('.msg'); const bodyEl=msg?msg.querySelector('.body'):null;
  const answer=bodyEl?bodyEl.textContent:'';
  const distilled='I asked my local AI assistant a question and want your help solving it well.\\n\\n'
    +'=== PROBLEM ===\\n'+d.prompt+'\\n\\n'
    +'=== LOCAL ASSISTANT ('+(d.model||'local')+') ANSWERED ===\\n'+answer+'\\n\\n'
    +'=== WHAT I NEED ===\\nGive a correct, complete solution. If the local answer is wrong '
    +'or incomplete, fix it and explain what it missed.';
  const done=()=>{ const o=btn.innerHTML; btn.textContent='copied \\u2713';
    setTimeout(()=>{btn.innerHTML=o;},1500); };
  if(navigator.clipboard&&navigator.clipboard.writeText){
    navigator.clipboard.writeText(distilled).then(done).catch(()=>{ btn.textContent='copy failed'; });
  } else { try{ const t=document.createElement('textarea'); t.value=distilled;
    document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); done();
  }catch(e){ btn.textContent='copy failed'; } }
  _sendRate(d.prompt,d.model,'escalated');   // escalating = the local model fell short
}
restoreCtls(); restoreEvoGithub(); restoreTab(); loadModels(); loadChat(); renderWhere(); renderEvoStatus(); loadAuth(); loadImageStatus();
// Ctrl/Cmd+Enter sends from the chat box (a plain Enter still inserts a newline, so
// multi-line prompts are easy to write).
(function(){ const p=$('p'); if(!p) return;
  p.addEventListener('keydown', function(e){
    if((e.ctrlKey||e.metaKey) && e.key==='Enter'){ e.preventDefault();
      if(!$('runbtn').disabled) go(); } }); })();
</script></body></html>"""

_MODEL_PICKER = """      <label class="ctl" title="Which model answers this run. Local models run offline via Ollama; the Claude cloud option appears when you're signed in. Bigger local models are smarter but slower — watch the activity timer on the reply.">model
        <select id="model" class="ctl-select" onchange="saveModel()">
          <option value="">loading…</option>
        </select>
      </label>"""


def _render_page() -> str:
    """Assemble the page from the evolvable theme (fonts + CSS), the declared run
    controls, and the template."""
    from . import __version__
    from . import controls, theme
    return (_PAGE_TEMPLATE
            .replace("__FONTS__", theme.FONT_LINK)
            .replace("__THEME__", theme.THEME_CSS)
            .replace("__CONTROLS__", controls.render_html())
            .replace("__MODEL_PICKER__", _MODEL_PICKER)
            .replace("__CONTROLS_JSON__", controls.spec_json())
            .replace("__VERSION__", __version__))

PAGE = _render_page()

def _clean_history(raw, *, max_turns: int = 40, max_len: int = 4000) -> list:
    """Sanitise conversation history from the client into [{role, text}] pairs.

    Untrusted input: coerce types, keep only known roles, bound count and size so a
    malformed or oversized payload can't wedge the pipeline. Content is treated as
    conversation data, never as instructions, by the prompt framing downstream.
    """
    if not isinstance(raw, list):
        return []
    out = []
    for item in raw[-max_turns:]:
        if not isinstance(item, dict):
            continue
        role = "user" if str(item.get("role")) == "user" else "ai"
        text = str(item.get("text", "")).strip()
        if text:
            out.append({"role": role, "text": text[:max_len]})
    return out

MEDIA_TYPES = {".mp4": "video/mp4", ".webm": "video/webm", ".mkv": "video/x-matroska",
               ".gif": "image/gif", ".webp": "image/webp", ".png": "image/png",
               ".jpg": "image/jpeg", ".jpeg": "image/jpeg"}


def media_type(path: Path) -> str:
    return MEDIA_TYPES.get(path.suffix.lower(), "application/octet-stream")


def media_file(want: str):
    """Resolve a browser-supplied path to a generated file, or None.

    This endpoint reads a file named by the page, so it is confined to the two
    directories AG writes media into. A path outside them — or a symlink pointing
    out of them, which is why this resolves before comparing — is not found.
    """
    from .config import STATE_DIR
    roots = [(STATE_DIR / "video").resolve(), (STATE_DIR / "images").resolve()]
    try:
        target = Path(want).resolve()
        if any(target.is_relative_to(r) for r in roots) and target.is_file():
            return target
    except (OSError, ValueError):
        pass
    return None


def _build_broker(cfg: Config, *, web=None):
    web = cfg.allow_web if web is None else web
    if not (web or cfg.allow_local_tools):
        return None
    from .permissions import PermissionBroker
    broker = PermissionBroker(allow_external_tools=True)
    if web:
        broker.grant("network")
    if cfg.allow_local_tools:
        broker.grant("filesystem_read")   # read-only file/dir access
        broker.grant("spawn_agent")       # delegate a subtask to a sub-agent
        if getattr(cfg, "allow_code_exec", False):
            broker.grant("code_exec")     # arbitrary Python — opt-in only
        # Self-extension: author/test/register a new skill, install its deps, fetch
        # allowlisted code. The acquisition_autonomy gate ("ask") still stops before
        # install/test unless the run opts into "auto".
        if getattr(cfg, "allow_acquire", False):
            broker.grant("write_skill")
            broker.grant("install_package")
            broker.grant("github_fetch")
            if getattr(cfg, "acquisition_autonomy", "ask") == "auto":
                broker.grant("acquire_auto")
    return broker

class _Handler(BaseHTTPRequestHandler):
    cfg: Config = Config()
    # Where the server is bound (filled in by serve()), for the GUI "where am I
    # running" indicator.
    bind_host: str = "127.0.0.1"
    bind_port: int = 8765
    # Evolve self-modifies source, so only one may run at a time. The server keeps
    # serving during an evolve (ThreadingHTTPServer), so this flag lets the GUI show
    # that a cycle is in progress and lets us reject overlapping evolves.
    _evolve_lock = threading.Lock()
    _evolving = threading.Event()
    # LoRA training runs in a background thread (it is long); this tracks its state so
    # the GUI can show progress and reject overlapping runs.
    _lora_train = {"running": False, "last": ""}
    _lora_lock = threading.Lock()
    # Cancellation registry: run_id -> True when the viewer asked to stop that run.
    # Checked every streamed chunk so Stop halts generation promptly and reliably,
    # rather than relying on a TCP write eventually failing.
    _cancel: dict = {}
    _cancel_lock = threading.Lock()
    # Last set of proposed self-edits, cached so the GUI can apply a chosen subset by
    # id (the browser never sends code back — AG applies exactly what it proposed).
    _proposal: dict = {}
    _proposal_directive: str = ""

    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_bytes(self, code, data: bytes, ctype: str):
        """Send raw bytes (a generated clip or image) rather than encoded text."""
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    # --- access control ----------------------------------------------------
    # Empty = loopback-only, no auth (unchanged local behaviour). Set by serve()
    # whenever the bind address is reachable from the network, because that turns
    # AG into an unauthenticated endpoint that runs your model, reads your files,
    # and can trigger evolve. MODALITY.md flagged exactly this; the fix is a token.
    auth_token: str = ""

    def _authorized(self) -> bool:
        if not self.auth_token:
            return True
        supplied = ""
        header = self.headers.get("Authorization", "")
        if header.startswith("Bearer "):
            supplied = header[7:].strip()
        if not supplied:
            from urllib.parse import urlparse, parse_qs
            supplied = (parse_qs(urlparse(self.path).query).get("token") or [""])[0]
        if not supplied:
            cookie = self.headers.get("Cookie", "")
            for part in cookie.split(";"):
                k, _, v = part.strip().partition("=")
                if k == "ag_token":
                    supplied = v.strip()
                    break
        import hmac
        # compare_digest: a plain == leaks the token's prefix through timing.
        return hmac.compare_digest(supplied, self.auth_token)

    def _deny(self) -> None:
        body = ("<!doctype html><meta charset=utf-8><title>Apple-Gorilla</title>"
                "<body style='font-family:system-ui;padding:2rem;max-width:34rem'>"
                "<h2>Access token required</h2><p>This Apple-Gorilla instance is "
                "bound to a network address, so it requires the access token printed "
                "in the terminal when it started.</p>"
                "<p>Open it as <code>http://HOST:PORT/?token=YOUR_TOKEN</code>.</p>")
        self._send(401, body)

    def _guard(self) -> bool:
        """True if the request may proceed; sends 401 and returns False if not."""
        if self._authorized():
            return True
        self._deny()
        return False

    def do_GET(self):
        if not self._guard():
            return
        # The token arrives as `/?token=...`, so the root route has to be matched
        # on the path alone. Only the root is normalised here: /media? carries a
        # meaningful query string, and every other route is an exact literal.
        if self.path.split("?", 1)[0] in ("/", "/index.html"):
            # Set the token as a cookie once, so the page's own fetch() calls (which
            # cannot carry the query string) authenticate for the rest of the session.
            if self.auth_token:
                body = PAGE.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Set-Cookie",
                                 f"ag_token={self.auth_token}; Path=/; SameSite=Strict")
                self.end_headers()
                self.wfile.write(body)
                return
            self._send(200, PAGE)
        elif self.path == "/tools":
            from . import inventory
            self._send(200, json.dumps(inventory.summary(self.cfg)),
                       "application/json")
        elif self.path == "/update/check":
            # On-demand (the page pings this once after a run). Never polled.
            from . import update
            status = update.check_model_update(self.cfg)
            self._send(200, json.dumps(status.as_dict()), "application/json")
        elif self.path == "/doctor":
            self._send(200, json.dumps(_doctor_data(self.cfg)), "application/json")
        elif self.path == "/evolve/history":
            from . import archive
            self._send(200, json.dumps({"history": archive.history(limit=20)}),
                       "application/json")
        elif self.path == "/whereami":
            self._send(200, json.dumps(self._whereami()), "application/json")
        elif self.path == "/models":
            self._send(200, json.dumps(_models_data(self.cfg)), "application/json")
        elif self.path == "/auth":
            from .model import signin_status
            st = signin_status()
            st["model"] = self.cfg.model
            st["console_url"] = "https://console.anthropic.com/settings/keys"
            self._send(200, json.dumps(st), "application/json")
        elif self.path.startswith("/media?"):
            # Serve a generated clip back to the page. Confined to AG's own output
            # directories: this endpoint takes a path from the browser, so anything
            # outside them is refused rather than read.
            import urllib.parse as _up
            want = _up.parse_qs(self.path.split("?", 1)[1]).get("path", [""])[0]
            target = media_file(want)
            if target is None:
                self._send(404, json.dumps({"error": "not found"}), "application/json")
                return
            self._send_bytes(200, target.read_bytes(), media_type(target))
        elif self.path == "/image/status":
            from . import comfy, images
            cfg = self.cfg
            on = bool(getattr(cfg, "allow_image_gen", False))
            backend = images.backend_for(cfg) if on else ""
            up = False
            host = cfg.sd_host
            models = []
            if on and backend == "comfy":
                host = cfg.comfy_host
                up = comfy.reachable(cfg)
                try:
                    models = comfy.describe(
                        comfy.load_workflow(cfg.comfy_image_workflow))
                except Exception:
                    models = []
            elif on:
                up = images.sd_reachable(cfg)
            self._send(200, json.dumps({
                "enabled": on, "reachable": up, "host": host, "backend": backend,
                "models": models,
                "video": bool(getattr(cfg, "allow_video_gen", False)),
            }), "application/json")
        elif self.path == "/fleet":
            from . import fleet
            self._send(200, json.dumps({
                "kill_active": fleet.kill_active(),
                "agents": [a.as_dict() for a in fleet.list_agents()]}),
                "application/json")
        elif self.path == "/skills":
            from . import skills
            items = skills.get_registry("root").list(include_disabled=True)
            self._send(200, json.dumps({"skills": [{
                "name": s.name, "description": s.description,
                "capabilities": s.capabilities, "enabled": s.enabled,
                "agent": s.agent, "source": s.source} for s in items]}),
                "application/json")
        elif self.path == "/bundle/check":
            from . import bundle
            checks = bundle.check()
            self._send(200, json.dumps({
                "portable": all(c.ok for c in checks),
                "checks": [c.as_dict() for c in checks]}), "application/json")
        elif self.path == "/lora/status":
            from . import lora
            feas = lora.feasibility(self.cfg)
            self._send(200, json.dumps({
                "feasibility": feas.as_dict(),
                "base": self.cfg.lora_base_model,
                "epochs": self.cfg.lora_epochs,
                "unsloth_pref": bool(getattr(self.cfg, "lora_use_unsloth", True)),
                "bases": lora.available_bases(feas.vram_gb),
                "recommended": lora.recommended_config(feas.vram_gb),
                "merge_ready": lora.merge_feasibility(self.cfg)["ok"],
                "dataset_size": lora.dataset_size(),
                "adapters": lora.list_adapters(),
                "training": dict(_Handler._lora_train)}), "application/json")
        else:
            self._send(404, "not found", "text/plain")

    def _whereami(self) -> dict:
        """Where and how AG is running right now — for the GUI location indicator."""
        from .model import _has_anthropic_creds, has_oauth_profile
        cfg = self.cfg
        host, port = self.bind_host, self.bind_port
        local_only = host not in ("0.0.0.0", "::")
        if cfg.backend == "auto":
            if _has_anthropic_creds() or has_oauth_profile():
                brain = "Claude (" + cfg.model + ")"
            else:
                brain = ("Ollama (" + cfg.ollama_model + ")"
                         if getattr(cfg, "offline_backend", "") == "ollama"
                         else "dry-run (stub)")
        elif cfg.backend == "ollama":
            brain = "Ollama (" + cfg.ollama_model + ")"
        elif cfg.backend == "anthropic":
            brain = "Claude (" + cfg.model + ")"
        else:
            brain = "dry-run (stub)"
        try:
            hostname = socket.gethostname()
        except Exception:
            hostname = "?"
        return {
            "host": host, "port": port, "local_only": local_only,
            "hostname": hostname, "url": f"http://127.0.0.1:{port}",
            "lan_url": (f"http://{_lan_ip()}:{port}" if not local_only else None),
            "backend": cfg.backend, "brain": brain,
            "evolving": self._evolving.is_set(),
            "can_evolve_while_running": True,
        }

    def _start_lora_train(self):
        """Kick off a QLoRA run in a background thread (it is long-running). Refuses to
        start a second concurrent run; result is reported via _lora_train for the GUI."""
        from . import lora
        with _Handler._lora_lock:
            if _Handler._lora_train.get("running"):
                self._send(200, json.dumps({"started": False,
                           "reason": "a training run is already in progress"}),
                           "application/json")
                return
            feas = lora.feasibility(self.cfg)
            if not feas.ok:
                reason = "not trainable here: " + (
                    ", ".join(feas.missing_deps) if feas.missing_deps
                    else "no CUDA GPU" if not feas.cuda else "; ".join(feas.notes))
                self._send(200, json.dumps({"started": False, "reason": reason}),
                           "application/json")
                return
            _Handler._lora_train = {"running": True, "last": ""}
        cfg = self.cfg

        def _worker():
            try:
                res = lora.train(cfg)
                _Handler._lora_train = {"running": False, "last": res.reason}
            except Exception as e:  # pragma: no cover - defensive
                _Handler._lora_train = {"running": False, "last": f"error: {e}"}

        threading.Thread(target=_worker, daemon=True).start()
        self._send(200, json.dumps({"started": True}), "application/json")

    def _start_lora_merge(self, adapter: str):
        """Merge an adapter -> GGUF -> Ollama in a background thread (long-running)."""
        from . import lora
        if not adapter:
            self._send(200, json.dumps({"started": False, "reason": "no adapter given"}),
                       "application/json")
            return
        with _Handler._lora_lock:
            if _Handler._lora_train.get("running"):
                self._send(200, json.dumps({"started": False,
                           "reason": "a LoRA job is already in progress"}), "application/json")
                return
            mf = lora.merge_feasibility(self.cfg)
            if not mf["ok"]:
                self._send(200, json.dumps({"started": False,
                           "reason": "; ".join(mf["notes"])}), "application/json")
                return
            _Handler._lora_train = {"running": True, "last": ""}
        cfg = self.cfg

        def _worker():
            try:
                res = lora.merge_to_gguf(cfg, adapter)
                _Handler._lora_train = {"running": False, "last": res.reason}
            except Exception as e:  # pragma: no cover
                _Handler._lora_train = {"running": False, "last": f"error: {e}"}

        threading.Thread(target=_worker, daemon=True).start()
        self._send(200, json.dumps({"started": True}), "application/json")

    def _handle_control(self, path: str, payload: dict):
        """Fleet / skills / bundle control-plane endpoints (non-streaming JSON)."""
        try:
            if path == "/fleet/act":
                from . import fleet
                action = str(payload.get("action", ""))
                agent = str(payload.get("agent", ""))
                if action == "kill":
                    fleet.engage_kill(); msg = "kill switch engaged"
                elif action == "revive":
                    fleet.clear_kill(); msg = "kill switch cleared"
                elif action == "clear":
                    msg = f"cleared {fleet.clear()} record(s)"
                elif action in ("disable", "enable"):
                    ok = fleet.set_status(agent, "disabled" if action == "disable" else "active")
                    msg = "ok" if ok else "agent not found"
                else:
                    msg = "unknown action"
                self._send(200, json.dumps({"ok": True, "msg": msg}), "application/json")
                return
            if path == "/skills/act":
                from . import skills
                reg = skills.get_registry("root")
                action = str(payload.get("action", ""))
                name = str(payload.get("name", ""))
                if action in ("disable", "enable"):
                    ok = reg.set_enabled(name, action == "enable")
                elif action == "remove":
                    ok = reg.remove(name)
                else:
                    ok = False
                self._send(200, json.dumps({"ok": bool(ok)}), "application/json")
                return
            if path == "/skills/acquire":
                from . import acquire
                from .permissions import PermissionBroker
                spec = str(payload.get("spec", "")).strip()
                if not spec:
                    self._send(200, json.dumps({"acquired": False,
                               "reason": "empty spec"}), "application/json")
                    return
                broker = PermissionBroker(allow_external_tools=True)
                for cap in ("write_skill", "install_package", "github_fetch", "code_exec"):
                    broker.grant(cap)
                client = make_client(self.cfg)
                res = acquire.author_skill(client, self.cfg, spec, broker=broker, approve=True)
                self._send(200, json.dumps(res.as_dict() | {"reason": res.reason}),
                           "application/json")
                return
            if path == "/bundle/export":
                from . import bundle
                dest = bundle.export()
                self._send(200, json.dumps({
                    "path": str(dest),
                    "bytes": dest.stat().st_size if dest.exists() else 0}),
                    "application/json")
                return
            if path == "/lora/build":
                from . import lora
                st = lora.build_dataset(self.cfg)
                self._send(200, json.dumps({
                    "total": st.total, "from_memory": st.from_memory,
                    "from_teacher": st.from_teacher}), "application/json")
                return
            if path == "/lora/train":
                self._start_lora_train()
                return
            if path == "/lora/set-base":
                from . import lora
                base = str(payload.get("base", "")).strip()
                valid = {b["id"] for b in lora.available_bases()}
                if base not in valid:
                    self._send(200, json.dumps({"ok": False, "reason": "unknown base"}),
                               "application/json")
                    return
                cfg = Config.load()
                cfg.lora_base_model = base
                cfg.save()
                _Handler.cfg = cfg
                self._send(200, json.dumps({"ok": True, "base": base}), "application/json")
                return
            if path == "/lora/set-opts":
                cfg = Config.load()
                if "epochs" in payload:
                    try:
                        ep = float(payload.get("epochs"))
                    except (TypeError, ValueError):
                        ep = cfg.lora_epochs
                    cfg.lora_epochs = max(0.5, min(10.0, ep))
                if "unsloth" in payload:
                    cfg.lora_use_unsloth = bool(payload.get("unsloth"))
                cfg.save()
                _Handler.cfg = cfg
                self._send(200, json.dumps({"ok": True, "epochs": cfg.lora_epochs,
                           "unsloth": bool(getattr(cfg, "lora_use_unsloth", True))}),
                           "application/json")
                return
            if path == "/lora/merge":
                adapter = str(payload.get("adapter", "")).strip()
                self._start_lora_merge(adapter)
                return
        except Exception as e:
            self._send(200, json.dumps({"ok": False, "error": str(e)}), "application/json")
            return
        self._send(404, "not found", "text/plain")

    def do_POST(self):
        if not self._guard():
            return
        if self.path in ("/fleet/act", "/skills/act", "/skills/acquire", "/bundle/export",
                         "/lora/build", "/lora/train", "/lora/set-base", "/lora/merge"):
            try:
                n = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(n) or b"{}") if n else {}
            except Exception:
                payload = {}
            self._handle_control(self.path, payload)
            return
        if self.path == "/image/start":
            from . import images
            cfg = self.cfg
            if not getattr(cfg, "allow_image_gen", False):
                self._send(200, json.dumps({"ok": False,
                           "error": "image generation is disabled"}), "application/json")
                return
            from . import comfy
            if images.backend_for(cfg) == "comfy":
                ok = comfy.ensure_running(cfg)
                err = ("" if ok else "could not start ComfyUI (none found, or it did "
                       "not come up). Install it, or set comfy_cmd to its launcher.")
                host = cfg.comfy_host
            else:
                ok = images.ensure_sd_running(cfg)
                err = ("" if ok else "could not start a Stable Diffusion server "
                       "(none installed/found, or it did not come up). Set sd_cmd to "
                       "your launcher, or start it manually with --api.")
                host = cfg.sd_host
            self._send(200, json.dumps({"ok": ok, "reachable": ok, "host": host,
                                        "error": err}), "application/json")
            return
        if self.path == "/image":
            from . import images
            cfg = self.cfg
            try:
                n = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(n) or b"{}") if n else {}
                prompt = str(payload.get("prompt", "")).strip()
                if not prompt:
                    raise ValueError("empty prompt")
            except Exception as e:
                self._send(200, json.dumps({"ok": False, "error": str(e)}),
                           "application/json")
                return
            if not getattr(cfg, "allow_image_gen", False):
                self._send(200, json.dumps(
                    {"ok": False, "error": "image generation is disabled "
                     "(set allow_image_gen)"}), "application/json")
                return
            try:
                res = images.generate(prompt, cfg,
                                      negative_prompt=str(payload.get("negative", "")))
                self._send(200, json.dumps({
                    "ok": True, "data_url": res.data_url, "path": res.path,
                    "width": res.width, "height": res.height}), "application/json")
            except Exception as e:
                self._send(200, json.dumps({"ok": False, "error": str(e)}),
                           "application/json")
            return
        if self.path == "/video":
            from . import video
            cfg = self.cfg
            try:
                n = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(n) or b"{}") if n else {}
                prompt = str(payload.get("prompt", "")).strip()
                if not prompt:
                    raise ValueError("empty prompt")
            except Exception as e:
                self._send(200, json.dumps({"ok": False, "error": str(e)}),
                           "application/json")
                return
            try:
                secs = float(payload.get("seconds") or 0) or None
            except (TypeError, ValueError):
                secs = None
            try:
                res = video.generate(prompt, cfg, seconds=secs,
                                     negative_prompt=str(payload.get("negative", "")))
                self._send(200, json.dumps({
                    "ok": True, "path": res.path, "seconds": res.seconds,
                    "width": res.width, "height": res.height}), "application/json")
            except Exception as e:
                self._send(200, json.dumps({"ok": False, "error": str(e)}),
                           "application/json")
            return
        if self.path == "/rate":
            # An honest learning signal from the UI: 👍/👎, a regenerate, or a Claude
            # escalation. The doc credits the model that produced the answer for the
            # task's tags. Never fabricates a score — it only records what the user did.
            try:
                n = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(n) or b"{}") if n else {}
            except Exception:
                payload = {}
            prompt = str(payload.get("prompt", ""))[:4000]
            model = str(payload.get("model", ""))[:100]
            signal = str(payload.get("signal", ""))
            if signal not in ("rating_up", "rating_down", "escalated"):
                self._send(200, json.dumps({"ok": False, "error": "bad signal"}),
                           "application/json")
                return
            try:
                from . import routing
                role = routing.role_for_model(self.cfg, model)
                routing.record(self.cfg, role, routing.tags_for(prompt), signal)
                self._send(200, json.dumps({"ok": True}), "application/json")
            except Exception as e:
                self._send(200, json.dumps({"ok": False, "error": str(e)}),
                           "application/json")
            return
        if self.path == "/stop":
            try:
                n = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(n) or b"{}") if n else {}
                rid = str(payload.get("run_id", ""))[:64]
            except Exception:
                rid = ""
            if rid:
                with _Handler._cancel_lock:
                    c = _Handler._cancel.get(rid)
                    if c is None:
                        _Handler._cancel[rid] = True   # sentinel: cancel on registration
                if hasattr(c, "cancel"):
                    c.cancel()                         # stop an already-running generation
            self._send(200, json.dumps({"ok": bool(rid)}), "application/json")
            return
        if self.path in ("/login/key", "/logout"):
            # Sign-in is a local action: only honour it from this machine, even when
            # bound to 0.0.0.0 for LAN viewing.
            if self.client_address and self.client_address[0] not in ("127.0.0.1", "::1"):
                self._send(403, json.dumps({"ok": False, "error": "sign-in is local-only"}),
                           "application/json")
                return
            from .model import save_api_key, clear_api_key, signin_status
            try:
                n = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(n) or b"{}") if n else {}
            except Exception:
                payload = {}
            if self.path == "/logout":
                clear_api_key()
                self._send(200, json.dumps({"ok": True, **signin_status()}),
                           "application/json")
                return
            key = str(payload.get("key", "")).strip()
            if len(key) < 10 or any(c.isspace() for c in key):
                self._send(200, json.dumps(
                    {"ok": False, "error": "that does not look like a valid key"}),
                    "application/json")
                return
            try:
                save_api_key(key)
                self._send(200, json.dumps({"ok": True, **signin_status()}),
                           "application/json")
            except Exception as e:
                self._send(200, json.dumps({"ok": False, "error": str(e)}),
                           "application/json")
            return
        if self.path == "/update/apply":
            self._stream_update()
            return
        if self.path == "/bench":
            # Drain the request body first: closing the socket with an unread body
            # makes the client see a TCP reset instead of the streamed response.
            try:
                self.rfile.read(int(self.headers.get("Content-Length", "0")))
            except Exception:
                pass
            self._stream_bench()
            return
        if self.path in ("/evolve", "/evolve/propose", "/evolve/apply"):
            # Evolve self-modifies source + commits, so gate it to the local machine
            # even when the app is bound to 0.0.0.0 for phone/LAN *viewing*.
            if self.client_address and self.client_address[0] not in ("127.0.0.1", "::1"):
                self._send(403, json.dumps({"error": "evolve is local-only"}),
                           "application/json")
                return
            try:
                n = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(n) or b"{}")
            except Exception:
                payload = {}
            if self.path == "/evolve/apply":
                self._stream_apply(payload)
            elif self.path == "/evolve":
                self._stream_evolve(payload)   # legacy automatic path (not used by GUI)
            else:
                self._stream_propose(payload)
            return
        if self.path != "/run":
            self._send(404, "not found", "text/plain")
            return
        try:
            n = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(n) or b"{}")
            prompt = str(payload.get("prompt", "")).strip()
            if not prompt:
                raise ValueError("empty prompt")
        except Exception as e:
            self._send(200, json.dumps({"error": str(e)}), "application/json")
            return
        history = _clean_history(payload.get("history"))
        model = str(payload.get("model", "")).strip()[:100]
        verbose = bool(payload.get("verbose", False))
        run_id = str(payload.get("run_id", ""))[:64]
        session_id = str(payload.get("session_id", ""))[:80]
        # Every declared run control, validated and reduced to the Config fields it
        # changes for this run only. A key that isn't sent keeps the standing config
        # value, so an older client or a bare `{"prompt": ...}` behaves as before.
        from . import controls
        self._stream_run(prompt, history, model, verbose, run_id,
                         session_id=session_id,
                         overrides=controls.overrides_for(payload))

    def _ndjson_writer(self):
        """Begin a streamed NDJSON response and return a write(event) callback."""
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

        def write(ev: dict) -> None:
            self.wfile.write((json.dumps(ev) + "\n").encode("utf-8"))
            self.wfile.flush()
        return write

    def _stream_update(self):
        """Pull/update the configured Ollama model, streaming progress (user-approved
        via the page's yes/no click — this endpoint only runs on an explicit POST)."""
        from . import update
        write = self._ndjson_writer()
        cfg = self.cfg
        try:
            write({"stage": "update", "level": "tool",
                   "msg": f"updating {cfg.ollama_model}…", "data": {}})
            ok, final = update.pull_model(cfg, emit=write)
            write({"stage": "done", "level": "result" if ok else "error",
                   "msg": final, "data": {"ok": ok, "final": final}})
        except (BrokenPipeError, ConnectionError):
            return
        except Exception as e:
            try:
                write({"stage": "error", "level": "error", "msg": str(e), "data": {}})
            except Exception:
                pass

    def _stream_bench(self):
        """Score AG on its objective benchmark, streaming per-task progress."""
        from . import bench
        write = self._ndjson_writer()
        cfg = self.cfg
        try:
            client = make_client(cfg)
            res = bench.run_benchmark(client, cfg, emit=write)
            write({"stage": "done", "level": "result", "msg": "benchmark complete",
                   "data": {"fitness": res.fitness, "pass_rate": res.pass_rate,
                            "passed": res.passed, "n": res.n, "mode": res.mode,
                            "failing": res.failed_ids}})
        except (BrokenPipeError, ConnectionError):
            return
        except Exception as e:
            try:
                write({"stage": "error", "level": "error", "msg": str(e), "data": {}})
            except Exception:
                pass

    def _stream_evolve(self, payload):
        """Run one gated self-improvement cycle, streaming its progress + verdict.

        Only one evolve runs at a time; the server keeps answering /run requests
        meanwhile (AG CAN evolve while running). Overlapping evolves are rejected.
        """
        from . import evolve as evolve_mod
        write = self._ndjson_writer()
        cfg = self.cfg
        # Reject a second concurrent evolve rather than corrupting a half-applied edit.
        if not self._evolve_lock.acquire(blocking=False):
            write({"stage": "done", "level": "info",
                   "msg": "an evolve cycle is already running — try again when it finishes",
                   "data": {"busy": True, "adopted": False, "rolled_back": False,
                            "reason": "evolve already in progress"}})
            return
        self._evolving.set()
        try:
            client = make_client(cfg)
            # Optional split backend: a stronger model proposes; deploy backend measures.
            evolver_client = None
            prop = str((payload or {}).get("proposer", "")).strip()
            directive = str((payload or {}).get("directive", "")).strip()
            if prop and prop != cfg.backend:
                try:
                    evolver_client = make_client(cfg, backend=prop)
                    write({"stage": "evolve", "level": "tool", "data": {},
                           "msg": f"proposer: {prop}  |  fitness measured on: {cfg.backend}"})
                except Exception as e:
                    write({"stage": "evolve", "level": "error", "data": {},
                           "msg": f"proposer '{prop}' unavailable ({e}); using deploy backend"})
            write({"stage": "evolve", "level": "tool",
                   "msg": ("starting self-improvement cycle"
                           + (" toward your request…" if directive else "…")),
                   "data": {}})
            res = evolve_mod.evolve(client, cfg, emit=write,
                                    evolver_client=evolver_client, directive=directive)
            write({"stage": "done",
                   "level": "result" if res.adopted else "info",
                   "msg": res.reason, "data": {
                       "adopted": res.adopted, "rolled_back": res.rolled_back,
                       "verdict": res.verdict, "incumbent": res.incumbent_fitness,
                       "candidate": res.candidate_fitness, "delta": res.fitness_delta,
                       "changed": res.changed, "rationale": res.rationale,
                       "reason": res.reason, "snapshot_id": res.snapshot_id}})
        except (BrokenPipeError, ConnectionError):
            return
        except Exception as e:
            try:
                write({"stage": "error", "level": "error", "msg": str(e), "data": {}})
            except Exception:
                pass
        finally:
            self._evolving.clear()
            self._evolve_lock.release()

    def _stream_propose(self, payload):
        """Generate candidate self-edits and stream them for the user to choose from.

        Nothing is applied here — the automatic adopt/reject decision is replaced by
        this propose→select→apply flow. The full patches are cached server-side so the
        browser only sends back the ids it selected.
        """
        import dataclasses
        from . import evolve as evolve_mod
        write = self._ndjson_writer()
        cfg = self.cfg
        # Honor the GUI's "use vetted GitHub references" toggle for this propose only.
        if (payload or {}).get("github"):
            cfg = dataclasses.replace(cfg, evolve_use_github=True)
        if not self._evolve_lock.acquire(blocking=False):
            write({"stage": "done", "level": "info",
                   "msg": "an evolve cycle is already running — try again shortly",
                   "data": {"busy": True, "patches": []}})
            return
        try:
            client = make_client(cfg)
            evolver_client = None
            prop = str((payload or {}).get("proposer", "")).strip()
            directive = str((payload or {}).get("directive", "")).strip()
            if prop and prop != cfg.backend:
                try:
                    evolver_client = make_client(cfg, backend=prop)
                    write({"stage": "evolve", "level": "tool", "data": {},
                           "msg": f"proposer: {prop}"})
                except Exception as e:
                    write({"stage": "evolve", "level": "error", "data": {},
                           "msg": f"proposer '{prop}' unavailable ({e}); using deploy backend"})
            res = evolve_mod.propose(client, cfg, emit=write,
                                     evolver_client=evolver_client, directive=directive)
            _Handler._proposal = {p.id: p for p in res.patches}
            _Handler._proposal_directive = res.directive
            write({"stage": "done",
                   "level": "result" if res.attempted else "info",
                   "msg": res.reason, "data": res.as_dict()})
        except (BrokenPipeError, ConnectionError):
            return
        except Exception as e:
            try:
                write({"stage": "error", "level": "error", "msg": str(e), "data": {}})
            except Exception:
                pass
        finally:
            self._evolve_lock.release()

    def _stream_apply(self, payload):
        """Apply the user-selected subset of the last proposal (by id), streaming it.

        The human's selection IS the decision; only the safety test gate still applies.
        """
        from . import evolve as evolve_mod
        write = self._ndjson_writer()
        cfg = self.cfg
        ids = (payload or {}).get("ids") or []
        measure = bool((payload or {}).get("measure", False))
        cache = getattr(_Handler, "_proposal", {}) or {}
        selected = []
        for i in ids:
            p = cache.get(str(i))
            if p is not None and getattr(p, "valid", False):
                selected.append({"path": p.path, "new_content": p.new_content})
        if not selected:
            write({"stage": "done", "level": "info",
                   "msg": "nothing to apply — the proposal expired or held no valid "
                          "selection; click Evolve again",
                   "data": {"adopted": False, "rolled_back": False, "changed": [],
                            "reason": "no valid selection"}})
            return
        if not self._evolve_lock.acquire(blocking=False):
            write({"stage": "done", "level": "info",
                   "msg": "an evolve cycle is already running — try again shortly",
                   "data": {"busy": True, "adopted": False, "rolled_back": False}})
            return
        self._evolving.set()
        try:
            client = make_client(cfg)
            write({"stage": "evolve", "level": "tool", "data": {},
                   "msg": f"applying {len(selected)} selected change(s)"
                          + (" and measuring fitness…" if measure else "…")})
            res = evolve_mod.apply_selected(
                client, cfg, selected, emit=write, measure=measure,
                note=getattr(_Handler, "_proposal_directive", ""))
            write({"stage": "done",
                   "level": "result" if res.adopted else "info",
                   "msg": res.reason, "data": {
                       "adopted": res.adopted, "rolled_back": res.rolled_back,
                       "verdict": res.verdict, "incumbent": res.incumbent_fitness,
                       "candidate": res.candidate_fitness, "delta": res.fitness_delta,
                       "changed": res.changed, "rationale": res.rationale,
                       "reason": res.reason, "snapshot_id": res.snapshot_id}})
            if res.adopted:
                _Handler._proposal = {}   # consumed
        except (BrokenPipeError, ConnectionError):
            return
        except Exception as e:
            try:
                write({"stage": "error", "level": "error", "msg": str(e), "data": {}})
            except Exception:
                pass
        finally:
            self._evolving.clear()
            self._evolve_lock.release()

    def _parse_model_choice(self, choice: str):
        """Validate a "<backend>:<model>" selector value into per-run overrides.

        Returns a dict of Config overrides, or {} to use the configured default. We
        only honour a backend we actually support and, for the cloud option, only the
        configured Claude model — never an arbitrary string from the request. An
        Ollama model name is accepted as-is (the user may have just pulled it); if it
        isn't really available the run surfaces a clear error rather than pretending.
        """
        if not choice or ":" not in choice:
            return {}
        backend, _, model = choice.partition(":")
        backend, model = backend.lower().strip(), model.strip()
        if backend == "anthropic":
            return {"backend": "anthropic", "model": self.cfg.model}
        if backend == "ollama" and model:
            return {"backend": "ollama", "ollama_model": model}
        return {}

    def _stream_run(self, prompt: str, history=None, model="", verbose=False,
                    run_id="", *, session_id="", overrides=None):
        """Run the pipeline, streaming each stage event as one NDJSON line.

        `overrides` is the set of Config fields this request changes, already validated
        by ag.controls — the same machinery the CLI uses sits underneath, so a control
        in the GUI reflects what actually happens rather than describing it.

        The model's output is always streamed internally via `on_delta`: when
        `verbose` is set the chunks are forwarded to the browser as 'delta' events so
        the viewer sees the reasoning/output live; otherwise a light heartbeat keeps
        the connection observable. Either way, if the viewer disconnects (Stop button /
        closed tab) the next write fails, we raise, and generation is halted upstream.
        """
        import dataclasses
        from .pipeline import capture_memory
        write = self._ndjson_writer()
        # Per-request overrides, without mutating the shared handler config.
        merged = dict(overrides or {})
        merged.update(self._parse_model_choice(model))
        cfg = dataclasses.replace(self.cfg, **merged)
        # Ambient web fires only when the prompt actually needs external/current info
        # (a research-type task), not on chat or self-contained work like coding — that
        # was making simple requests slow. An explicit model/run still has web available.
        from . import routing
        web_eff = bool(cfg.allow_web) and ("research" in routing.tags_for(prompt))
        broker = _build_broker(cfg, web=web_eff)
        # Normalize the session id (a per-tab id from the client) so this run's working
        # memory loads and saves under one key; empty falls back to a raw transcript.
        if session_id and getattr(cfg, "working_memory", True):
            try:
                from .memory import working
                session_id = working.resolve_session(session_id)
            except Exception:
                pass

        # A Canceller lets /stop close the upstream model connection at any point (even
        # during prompt-eval), so Stop is prompt and reliable — not only once tokens flow.
        canceller = Canceller()
        if run_id:
            with _Handler._cancel_lock:
                pre = _Handler._cancel.get(run_id)
                _Handler._cancel[run_id] = canceller
            if pre is True:            # /stop arrived before we registered
                canceller.cancel()

        state = {"n": 0}

        def on_delta(text):
            state["n"] += 1
            try:
                if verbose:
                    write({"stage": "delta", "level": "token", "msg": "",
                           "data": {"text": text}})
                elif state["n"] % 16 == 0:
                    write({"stage": "progress", "level": "info", "msg": "",
                           "data": {"tokens": state["n"]}})
            except (BrokenPipeError, ConnectionError):
                raise _Interrupted()   # viewer closed the tab mid-stream

        try:
            client = make_client(cfg)
            rec = run_pipeline(client, cfg, prompt, web=web_eff, broker=broker,
                               emit=write, history=history, session_id=session_id,
                               on_delta=on_delta, cancel=canceller)
            write({"stage": "done", "level": "result", "msg": "done", "data": {
                "answer": rec.answer, "scorecard": rec.scorecard,
                "elapsed_s": rec.elapsed_s, "dry_run": rec.dry_run,
                "model_used": rec.model_used}})
            # Fill long-term memory AFTER the answer is on screen, so it never delays
            # the response. Best-effort; a "saved N fact(s)" event streams if it stores.
            try:
                from .pipeline import format_history
                convo = format_history(history,
                                       max_turns=getattr(cfg, "max_history_turns", 12))
                capture_memory(client, cfg, prompt, rec.answer,
                               conversation=convo, session_id=session_id,
                               history=history, emit=write,
                               web_sources=rec.web_sources)
            except Exception:
                pass
        except (BrokenPipeError, ConnectionError, _Interrupted, Cancelled):
            return  # viewer stopped the run or navigated away mid-stream
        except Exception as e:
            try:
                write({"stage": "error", "level": "error", "msg": str(e), "data": {}})
            except Exception:
                pass
        finally:
            if run_id:
                with _Handler._cancel_lock:
                    _Handler._cancel.pop(run_id, None)

    def log_message(self, *a):  # quiet
        pass

def _doctor_data(cfg: Config) -> dict:
    """Environment / readiness snapshot for the GUI Status button (same facts as the
    `ag doctor` CLI). Read-only; probes Ollama without hard-failing."""
    import os
    import urllib.request
    from . import archive, backup, bench
    from .evolve import gate_available
    from .model import has_oauth_profile, oauth_token_status

    has_key = bool(os.environ.get("ANTHROPIC_API_KEY")
                   or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
    oauth = has_oauth_profile()
    reachable, models = False, []
    try:
        with urllib.request.urlopen(cfg.ollama_host.rstrip("/") + "/api/tags",
                                    timeout=1.5) as r:
            reachable = True
            models = [m.get("name", "?")
                      for m in json.loads(r.read().decode("utf-8")).get("models", [])]
    except Exception:
        pass
    if cfg.backend == "auto":
        if has_key or oauth:
            eff = "anthropic"
        elif getattr(cfg, "offline_backend", "") == "ollama":
            eff = "ollama"
        else:
            eff = "dry-run (stub)"
    else:
        eff = cfg.backend
    last = archive.adopted_history(limit=1)
    return {
        "backend": cfg.backend, "effective_backend": eff, "model": cfg.model,
        "ollama_model": cfg.ollama_model, "ollama_reachable": reachable,
        "ollama_models": models, "api_key": has_key, "oauth": oauth,
        "oauth_token": oauth_token_status() if oauth else "none",
        "autonomy": cfg.autonomy_level, "evolver_backend": cfg.evolver_backend,
        "fitness_gate": cfg.fitness_gate, "bench_tasks": len(bench.load_tasks(cfg=cfg)),
        "bench_mode": cfg.bench_mode, "bench_samples": cfg.bench_samples,
        "evolve_gate": "ready" if gate_available() else "unavailable (pip install pytest)",
        "snapshots": len(backup.list_snapshots()),
        "last_improvement": last[0] if last else None, "allow_web": cfg.allow_web,
    }

def _list_ollama_models(cfg: Config) -> list:
    """Names of models currently pulled in the local Ollama (empty if unreachable)."""
    import urllib.request
    try:
        with urllib.request.urlopen(cfg.ollama_host.rstrip("/") + "/api/tags",
                                    timeout=1.5) as r:
            return [m.get("name") for m
                    in json.loads(r.read().decode("utf-8")).get("models", [])
                    if m.get("name")]
    except Exception:
        return []

def _models_data(cfg: Config) -> dict:
    """Models the GUI selector can offer, and the current effective choice.

    Each option's value is "<backend>:<model>" so the /run handler knows both which
    backend to use and which model. Local (Ollama) models are always listed if the
    server is reachable; the cloud Claude model is offered only when creds/OAuth are
    present. `current` reflects what a run would use right now with no override."""
    import re as _re
    from .model import _has_anthropic_creds, has_oauth_profile
    models = _list_ollama_models(cfg)
    cloud = bool(_has_anthropic_creds() or has_oauth_profile())

    # Curate the list: drop what can't answer a prompt (embedding models) and raw
    # timestamped build artifacts (e.g. ...-obliterated-20260918-215836) that just
    # duplicate a stable alias — the "unused models" clutter. AG's two working models
    # (the abliterated task model and the instruct chat model) are labelled and sorted
    # to the top; everything else pulled remains selectable.
    def _keep(name: str) -> bool:
        low = name.lower()
        if "embed" in low:
            return False
        if _re.search(r"-\d{8}-\d{6}", name):   # a dated build snapshot, not a model
            return False
        return True

    primary, spec = cfg.ollama_model, getattr(cfg, "specialist_model", "")

    def _label(m: str) -> str:
        if m == primary:
            return f"{m} · local · primary"
        if m == spec:
            return f"{m} · local · specialist (abliterated)"
        return f"{m} · local"

    def _rank(m: str) -> int:
        return 0 if m == primary else 1 if m == spec else 2

    kept = sorted((m for m in models if _keep(m)), key=lambda m: (_rank(m), m.lower()))
    # Local models first so the offline default is the obvious top choice; the cloud
    # Claude option is listed last and labelled with its cost, since picking it is the
    # user's explicit opt-in to spend API tokens.
    options = [{"value": f"ollama:{m}", "label": _label(m)} for m in kept]
    if cloud:
        options.append({"value": f"anthropic:{cfg.model}",
                        "label": f"{cfg.model} · Claude cloud (uses API tokens)"})

    if cfg.backend == "anthropic" or (cfg.backend == "auto" and cloud):
        current = f"anthropic:{cfg.model}"
    elif cfg.backend == "ollama" or (
            cfg.backend == "auto" and getattr(cfg, "offline_backend", "") == "ollama"):
        current = f"ollama:{cfg.ollama_model}"
    else:
        current = f"ollama:{cfg.ollama_model}"
    return {"options": options, "current": current, "cloud": cloud,
            "ollama_reachable": bool(models)}

def run_prompt(cfg: Config, prompt: str) -> tuple[str, str]:
    """Run one prompt through the pipeline; returns (answer, meta-string).

    Non-streaming helper kept for programmatic use and tests; the web UI uses the
    streaming path in `_Handler._stream_run`.
    """
    client = make_client(cfg)
    broker = _build_broker(cfg)
    rec = run_pipeline(client, cfg, prompt, web=cfg.allow_web, broker=broker)
    sc = rec.scorecard or {}
    meta = f"dry_run={rec.dry_run} speed={sc.get('speed', '?')}"
    return rec.answer, meta

def _lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def _is_loopback(host: str) -> bool:
    """Only these bind addresses are unreachable from the network."""
    return host in ("127.0.0.1", "::1", "localhost", "")


def serve(host: str = "127.0.0.1", port: int = 8765, open_browser: bool = False,
          token: str = "", no_auth: bool = False):
    _Handler.cfg = Config.load()
    _Handler.bind_host = host
    _Handler.bind_port = port

    # Binding off-loopback publishes an endpoint that runs the model, reads files
    # through the tool layer, and can start an evolve cycle. Requiring a token there
    # — and generating one automatically, so it cannot be skipped by forgetting —
    # makes the safe path the default path. Loopback is untouched: a personal tool
    # on your own machine should not ask you to log in.
    if _is_loopback(host) or no_auth:
        _Handler.auth_token = ""
    else:
        import secrets
        _Handler.auth_token = token or secrets.token_urlsafe(24)

    httpd = ThreadingHTTPServer((host, port), _Handler)
    tok = _Handler.auth_token
    qs = f"/?token={tok}" if tok else "/"
    local = f"http://127.0.0.1:{port}{qs}"
    print(f"Apple-Gorilla web app running:")
    print(f"  this machine : {local}")
    if not _is_loopback(host):
        print(f"  on your phone: http://{_lan_ip()}:{port}{qs}  (same wifi)")
    else:
        print(f"  (localhost only; use --host 0.0.0.0 to reach it from your phone)")
    if tok:
        print(f"\n  ACCESS TOKEN: {tok}")
        print("  This instance is reachable from the network, so requests without "
              "the token are refused.")
        print("  Open the link above (the token is set as a cookie on first load).")
    elif not _is_loopback(host):
        print("\n  WARNING: --no-auth on a network address. Anyone who can reach "
              f"port {port} can run this instance.")
    print("Ctrl+C to stop.")
    if open_browser:
        try:
            import webbrowser
            webbrowser.open(local)
        except Exception:
            pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.shutdown()
